<?php
/*
 * Include licence key from server
 */
function licence_Key( $licencekey='E9E9F-9993432-45543' ) {
	
    if ( !empty( $licencekey ) ) {
        $licencekey = $licencekey;
    }
    return $licencekey;
}
add_action( 'after_theme_setup', 'licence_Key' );