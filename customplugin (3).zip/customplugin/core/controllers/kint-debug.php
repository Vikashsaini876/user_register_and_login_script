<?php

if ( ! defined( 'ABSPATH' ) )
	exit;
	
class Kint_Debug {

    // Add Hook
    public function __construct()
	{
        add_action('plugins_loaded', array($this, 'keny_debug_plugin_Library'));
    }

	// Debug plugin by using below functions
    public function keny_debug_plugin_Library()
	{
		//Kint::dump($GLOBALS, $_SERVER); // pass any number of parameters
		//d($GLOBALS, $_SERVER); // or simply use d() as a shorthand

		//Kint::trace(); // Debug backtrace
		//d(1); // Debug backtrace shorthand

		//s($GLOBALS); // Basic output mode

		//~d($GLOBALS); // Text only output mode

		//Kint::$enabled_mode = false; // Disable kint
		//d('Get off my lawn!'); // Debugs no longer have any effect 
    }
}