<?php

class Kint_Object_Nothing extends Kint_Object
{
    public $hints = array('nothing');
}
