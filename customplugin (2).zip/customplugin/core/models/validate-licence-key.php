<?php

if ( ! defined( 'ABSPATH' ) )
	exit;

class Validate_Licence_Key{
	   
	   // Set plugin licence key
	   public function set_plugin_licence_Key() {
				$activation_key = $_POST["activation_key"];
                $sanitized_activation_key = filter_var($activation_key, FILTER_SANITIZE_STRING);
				global $wpdb; 
				$db_table_name = $wpdb->prefix . 'custom_plugin_development'; 
				$id = 1;	 
				$update = $wpdb->query($wpdb->prepare( "UPDATE $db_table_name SET activated='$sanitized_activation_key' WHERE id = %d", $id ));
				return $update;
	   }   
	   
	   // Validate plugin licence key
	   public function validate_plugin_licence_Key() {
				global $wpdb; 
				$db_table_name = $wpdb->prefix . 'custom_plugin_development'; 
				$get_results = $wpdb->get_results("SELECT * FROM $db_table_name", ARRAY_A);
				$result['activation_key_check'] = $get_results[0][activation_key];
				$result['activated_key_check'] = $get_results[0][activated];
				return $result;
	   } 
}