<?php

if ( ! defined( 'ABSPATH' ) )
	exit;

class Admin_Panel_Configuration {

	 public function __construct() {

				// Add hook for adding admin menus
				add_action('admin_menu', 'mt_add_pages');

				// Init hook
				function mt_add_pages() {
					// Add menu
					add_menu_page(__('Plugin Panel','custom-plugin-development'), __('Plugin Panel','custom-plugin-development'), 'manage_options', 'licence-key', 'mt_toplevel_Page' );
					
                    // Validate plugin and show panels
					$validate = new Validate_Licence_Key();
					$result = $validate->validate_plugin_licence_Key();
					
					$licence_key = licence_Key();
					
				    if($result['activated_key_check'] === $result['activation_key_check'] && $result['activated_key_check'] === $licence_key ){
						
						// Add a submenu to the custom top-level menu:
						add_submenu_page('licence-key', __('Sublevel 1','custom-plugin-development'), __('Sublevel 1','custom-plugin-development'), 'manage_options', 'sub-page', 'mt_sublevel_Page');

						// Add a second submenu to the custom top-level menu:
						add_submenu_page('licence-key', __('Sublevel 2','custom-plugin-development'), __('Sublevel 2','custom-plugin-development'), 'manage_options', 'sub-page2', 'mt_sublevel_Page2');
						
					}
				}

				function mt_toplevel_Page() {
				     
					 if(isset($_POST["activate"]))
					 {
				        // Set plugin licence_key
						 $validate = new Validate_Licence_Key();
						 $update = $validate->set_plugin_licence_Key();
						 
							if($update)
							{
							    // Validate plugin licence_key
								$validate = new Validate_Licence_Key();
								$result = $validate->validate_plugin_licence_Key();
								
									if($result['activated_key_check'] === $result['activation_key_check'])
									{
										// Set plugin authorization success message
										$validate = new Admin_Notices();
								        $result = $validate->licence_key_validation_Successfull();
									}
									else
									{
										// Set plugin authorization failed message
										$validate = new Admin_Notices();
								        $validate->licence_key_validation_Failed();
									}
									
							}
							
					  }

					// Input form 			
                    $validate = new Licence_Key_Form();
					$validate->licence_key_form_Field();					
				}
                
				// Sublevel menu 1
				function mt_sublevel_Page() {
				?>
				<h2><?php _e('Sublevel 1', 'custom-plugin-development'); ?></h2>
				<p><?php _e('Content goes here...', 'custom-plugin-development'); ?></p>
				<?php
				}

				// Sublevel menu 2
				function mt_sublevel_Page2() {
				?>
				<h2><?php _e('Sublevel 2', 'custom-plugin-development'); ?></h2>
				<p><?php _e('Content goes here...', 'custom-plugin-development'); ?></p>
				<?php
				}
				
	   
	 }
	 
	 
}
	