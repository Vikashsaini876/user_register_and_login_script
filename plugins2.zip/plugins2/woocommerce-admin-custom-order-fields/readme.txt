=== WooCommerce Admin Custom Order Fields ===
Author: woothemes, skyverge
Tags: woocommerce
Requires at least: 4.1
Tested up to: 4.7
Requires WooCommerce at least: 2.4.13
Tested WooCommerce up to: 2.6.9

Easily add custom fields to your WooCommerce orders and display them in the Orders admin, the My Orders section, and even order emails!

See http://docs.woothemes.com/document/woocommerce-admin-custom-order-fields/ for full documentation.

== Installation ==

1. Upload the entire 'wocoommerce-admin-custom-order-fields' folder to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress
