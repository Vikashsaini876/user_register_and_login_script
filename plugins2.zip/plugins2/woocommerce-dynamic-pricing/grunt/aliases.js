module.exports = {
	'default': [
		'makepot',
		'notify:default'
	],
};
