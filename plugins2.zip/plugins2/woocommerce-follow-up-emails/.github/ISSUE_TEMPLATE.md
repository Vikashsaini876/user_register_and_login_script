<!-- Thanks for contributing to this extension! Pick a clear title ("Order: Unable to refund when gateway X is used") and proceed. -->

#### Affected ticket(s)

<!-- The ZenDesk tickets that are affected by this issue -->

#### What I expected

<!-- What you or customer expected when performing the steps -->

#### What happened instead

<!-- What actual results you or customer got -->

#### Steps to reproduce the issue

<!-- Please add detailed steps to reproduce the issue. Make sure it's reproducible locally. Other extensions should be deactivated and standard theme is used when reproducing the issue locally -->

<!--
PLEASE NOTE
- These comments won't show up when you submit the issue.
- Everything is optional, but try to add as many details as possible.
- Screenshot worth a thousand words, use screenshots if possible.
- If requesting a new feature, explain why you'd like to see it added.
- Please apply appropriate labels on the issue
-->


-------------------

- [ ] Issue assigned to next milestone.
- [ ] Issue assigned a priority (will be assessed by maintainers).
