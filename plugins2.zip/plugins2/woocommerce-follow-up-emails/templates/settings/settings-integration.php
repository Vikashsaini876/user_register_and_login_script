<form action="admin-post.php" method="post" enctype="multipart/form-data">

	<?php do_action( 'fue_settings_integration' ); ?>

	<p class="submit">
		<input type="hidden" name="action" value="fue_followup_save_settings" />
		<input type="hidden" name="section" value="<?php echo $tab; ?>" />
		<input type="submit" name="save" value="<?php _e('Save Settings', 'follow_up_emails'); ?>" class="button-primary" />
	</p>

</form>