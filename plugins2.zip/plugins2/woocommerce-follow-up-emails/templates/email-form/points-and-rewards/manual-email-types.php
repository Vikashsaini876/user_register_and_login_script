<?php foreach ( $options as $option => $value ): ?>
	<option value="<?php echo $option; ?>"><?php echo $value; ?></option>
<?php endforeach; ?>