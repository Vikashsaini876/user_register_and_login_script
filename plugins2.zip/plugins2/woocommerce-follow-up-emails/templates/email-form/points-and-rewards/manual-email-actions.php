<div class="send-type-points_rewards_points send-type-div">
	<input type="number" class="" name="points_rewards_points" id="points_rewards_points" style="width: 80px;" value="0" />
	<?php _e('Points', 'follow_up_emails'); ?>
</div>