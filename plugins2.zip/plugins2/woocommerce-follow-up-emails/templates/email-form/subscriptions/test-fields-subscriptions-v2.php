<p class="form-field">
	<span id="test_email_order">
		<?php _e( 'as Subscription: ', 'follow_up_emails' ); ?>
		<input type="number" id="subscription_id" placeholder="The subscription ID e.g. 105" size="5" class="test-email-field" min="1" />
	</span>
</p>