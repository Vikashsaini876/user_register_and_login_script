<?php if (isset($_GET['saved'])): ?>
	<div id="message" class="updated"><p><?php _e('Settings updated', 'follow_up_emails'); ?></p></div>
<?php endif; ?>