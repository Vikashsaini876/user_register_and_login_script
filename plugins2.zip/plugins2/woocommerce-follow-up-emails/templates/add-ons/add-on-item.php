<div>
	<h3><a href="<?php echo $addon->url; ?>" target="_blank"><?php echo $addon->name; ?></a></h3>

	<p><?php echo $addon->description; ?></p>
</div>