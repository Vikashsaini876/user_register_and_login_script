<?php

if ( ! defined( 'ABSPATH' ) )
	exit;

class Validate_Licence_Key{
	   
	   public function validate_plugin_licence() {
				global $wpdb; 
				$db_table_name = $wpdb->prefix . 'custom_plugin_development'; 
				$get_results = $wpdb->get_results("SELECT * FROM $db_table_name", ARRAY_A);
				$result['activation_key_check'] = $get_results[0][activation_key];
				$result['activated_key_check'] = $get_results[0][activated];
				return $result;
	   }   
}