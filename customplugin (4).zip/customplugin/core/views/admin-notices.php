<?php

if ( ! defined( 'ABSPATH' ) )
	exit;
	
class Admin_Notices{

	   public function __construct()
	   {
			    add_action('plugins_loaded', array($this, 'plugin_activation_notice'));
	   }

	   public function plugin_activation_notice()
	   {
				add_action( "admin_notices", function() {
				?>
				<div class='updated notice is-dismissible'>
				<p><?php _e('Thank you for using our plugin.Please activate plugin with your licence key. To get licence key please check your licence file into plugin root directory .', 'custom-plugin-development'); ?></p>
				</div>
				<?php
				});
	   }
	   
	   public function licence_key_validation_successfull()
	   {
	            ?>
				<div class='updated notice is-dismissible'>
				<p>
				<strong>
				<?php _e('Plugin Authorized Successfully.', 'custom-plugin-development'); ?>
				</strong>
				</p>
				</div>
                <?php
	   } 
	   
	   public function licence_key_validation_failed()
	   {
				?>
				<div class='notice notice-error is-dismissible'>
				<p>
				<strong>
				<?php _e('Plugin Authorization Failed, Please enter valid plugin licence key to get plugin access. To get licence key please check your licence file into plugin root directory.', 'custom-plugin-development');
				?>
				</strong>
				</p>
			    </div>
				<?php
	   }	
	  
}
