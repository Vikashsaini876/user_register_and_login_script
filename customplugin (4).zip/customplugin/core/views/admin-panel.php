<?php

if ( ! defined( 'ABSPATH' ) )
	exit;

class Admin_Panel_Configuration {

	 public function __construct() {

				// Hook for adding admin menus
				add_action('admin_menu', 'mt_add_pages');

				// action function for above hook
				function mt_add_pages() {
					add_menu_page(__('Test Plugin Panel','custom-plugin-development'), __('Test Plugin Panel','custom-plugin-development'), 'manage_options', 'activation-key', 'mt_toplevel_page' );
					
                    // Validate plugin and show panels
					$validate = new Validate_Licence_Key();
					$result = $validate->validate_plugin_licence();
													
				    if($result['activated_key_check'] === $result['activation_key_check']){
					// Add a submenu to the custom top-level menu:
					add_submenu_page('activation-key', __('Test Subleve l','custom-plugin-development'), __('Test Subleve l','custom-plugin-development'), 'manage_options', 'sub-page', 'mt_sublevel_page');

					// Add a second submenu to the custom top-level menu:
					add_submenu_page('activation-key', __('Test Sublevel 2','custom-plugin-development'), __('Test Sublevel 2','custom-plugin-development'), 'manage_options', 'sub-page2', 'mt_sublevel_page2');
					}
				}

				function mt_toplevel_page() {
				     
					 if(isset($_POST["activate"]))
					 {
						 $activation_key = $_POST["activation_key"];
                         $sanitized_activation_key = filter_var($activation_key, FILTER_SANITIZE_STRING);

						 global $wpdb; 
						 $db_table_name = $wpdb->prefix . 'custom_plugin_development'; 
						 $id = 1;
						 
						 $update = $wpdb->query($wpdb->prepare( "UPDATE $db_table_name SET activated='$sanitized_activation_key' WHERE id = %d", $id ));
						 
							if($update)
							{
							    // Validate plugin licence_key
								$validate = new Validate_Licence_Key();
								$result = $validate->validate_plugin_licence();
								
									if($result['activated_key_check'] === $result['activation_key_check'])
									{
										// Set plugin authorization success message
										$validate = new Admin_Notices();
								        $result = $validate->licence_key_validation_successfull();
									}
									else
									{
										// Set plugin authorization failed message
										$validate = new Admin_Notices();
								        $validate->licence_key_validation_failed();
									}
									
							}
							
					  }

					// input form 			
                    $validate = new Licence_Key_Form();
					$validate->licence_key_field_form();					
				}

				function mt_sublevel_page() {
				?>
				<h2><?php _e('Test Sublevel', 'custom-plugin-development'); ?></h2>
				<p><?php _e('My WordPress Blog', 'custom-plugin-development'); ?></p>
				<?php
				}

				function mt_sublevel_page2() {
				?>
				<h2><?php _e('Test Sublevel2', 'custom-plugin-development'); ?></h2>
				<p><?php _e('Content goes here...', 'custom-plugin-development'); ?></p>
				<?php
				}
				
	   
	 }
	 
	 
}
	