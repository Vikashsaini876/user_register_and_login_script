<?php
namespace Amasty\TextoverImages\Ui\DataProvider\Product\Form\Modifier;
use Magento\Catalog\Model\Locator\LocatorInterface;
use Magento\Catalog\Ui\DataProvider\Product\Form\Modifier\AbstractModifier;
use Magento\Ui\Component\Form\Fieldset;
use Magento\Ui\Component\Form\Field;
use Magento\Ui\Component\Form\Element\Textarea;
use Magento\Ui\Component\Form\Element\DataType\Text;
use Magento\Ui\Component\Form\Element\Checkbox;
//use Magento\Catalog\Model\Product\Attribute\Source\Boolean;
use Magento\Store\Model\ScopeInterface;
use Magento\Framework\Stdlib\ArrayManager;
use Magento\Framework\App\Config\ScopeConfigInterface;

class NewField extends AbstractModifier
{
	 protected $scopeConfig;
	 protected $locator;
	 protected $arrayManager;
	  
     public function __construct(
        LocatorInterface $locator,
        ArrayManager $arrayManager,
        ScopeConfigInterface $scopeConfig
    ) {
        $this->locator = $locator;
        $this->arrayManager = $arrayManager;
        $this->scopeConfig = $scopeConfig;
    }
	
    public function modifyData(array $data)
    {  
		$modelId = $this->locator->getProduct()->getId();
		
		if (!empty($modelId)){
			$objectManager = \Magento\Framework\App\ObjectManager::getInstance(); // Instance of object manager
			$resource = $objectManager->get('Magento\Framework\App\ResourceConnection');
			$connection = $resource->getConnection();
			$tableName = $resource->getTableName('textoverimage_config'); 
			
			$sql = "Select * FROM " . $tableName." WHERE product_id =$modelId";
			$result = $connection->fetchAll($sql);

			if(empty($result)){
				$result[0] = array(
				  'product_id' => $modelId,
				  'enable' => '0', 
				  'wrap_width' => '300', 
				  'left_pos' => '180', 
				  'top_pos' => '360',
				  'text_color' => 'FFF000',
				  'text_fontsize' => '28',
				  'text_fontfamily' => 'Ubuntu-Medium.TTF', 
				  'number_color' => 'dd0000', 
				  'number_fontsize' => '99',
				  'number_fontfamily' => 'KILLERBOOTS.TTF',
				  'max_textlimit' => '14', 
				  'max_nolimit' => '4'
				  );
				  $data[$modelId][static::DATA_SOURCE_DEFAULT]['imgcreater'] = (array)@$result[0];
			}
			$data[$modelId][static::DATA_SOURCE_DEFAULT]['imgcreater'] = (array)@$result[0];
		}
        return $data;
    }
	
	public function modifyMeta(array $meta)
    {
		return $meta;
    }
	/*
	protected function getValueFromConfig()
    {
        return $this->scopeConfig->getValue(
            Message::XPATH_CONFIG_GIFT_MESSAGE_ALLOW_ITEMS,
            ScopeInterface::SCOPE_STORE
        );
    }
	*/
}