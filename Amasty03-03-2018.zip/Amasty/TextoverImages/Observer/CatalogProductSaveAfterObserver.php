<?php

namespace Amasty\TextoverImages\Observer;
use Magento\Framework\Event\Observer as EventObserver;
use Magento\Framework\Event\ObserverInterface;

class CatalogProductSaveAfterObserver implements ObserverInterface
{
    /**
     * @var \Magento\Framework\View\LayoutInterface
     */
    protected $_layout;
    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $_storeManager;
    protected $_request;
    /**
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param \Magento\Framework\View\LayoutInterface $layout
     */
    public function __construct(
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\View\LayoutInterface $layout,
        \Magento\Framework\App\RequestInterface $request
    )
    {
        $this->_layout = $layout;
        $this->_storeManager = $storeManager;
        $this->_request = $request;
    }
    /**
     * Add order information into GA block to render on checkout success pages
     *
     * @param EventObserver $observer
     * @return void
     */
    public function execute(EventObserver $observer)
    {
		$product_id = (int)$observer->getEvent()->getProduct()->getId();
		//$product_id = (int)$observer->getProduct()->getId();
		$postData = @$_REQUEST['product']['imgcreater'];

		if( isset($postData['enable']) ){
			
			$objectManager = \Magento\Framework\App\ObjectManager::getInstance(); // Instance of object manager
			$resource = $objectManager->get('Magento\Framework\App\ResourceConnection');
			$connection = $resource->getConnection();
			$tableName = $resource->getTableName('textoverimage_config'); 

			$sql = "Select * FROM " . $tableName." WHERE product_id = $product_id";
			$result = $connection->fetchAll($sql);
				
			if( !empty($result) )
				$sql = "UPDATE " . $tableName . " SET enable = '$postData[enable]',wrap_width = '$postData[wrap_width]',left_pos='$postData[left_pos]' WHERE product_id = $product_id";
			else
				$sql = "INSERT Into " . $tableName . " (product_id,enable,wrap_width,left_pos) Values ('$product_id','$postData[enable]','$postData[wrap_width]','$postData[left_pos]')";
			
			$r = $connection->query($sql);
		}
	
		return $this;
    }
}