/*
require([
    "jquery"
], function($){
    $(document).ready(function() { 
         $(".textoverimages_name,.textoverimages_no").keyup(function(){ 
			  var _name = $(".textoverimages_name").val(); 
			  var _no = $(".textoverimages_no").val();
			  var url = $(this).closest('.amasty-textoverimages-block').data('icurl')+"&img_text=" + _name +"&img_no=" + _no;
			//  $(".textoverimages_name,.textoverimages_no").prop('disabled',true);
			  $(".fotorama__img").parent().parent().append('<div id="loading_image"></div>').show();
			   $("#textoverimages_img").val(url);
			 _img = new Image();
			 _img.src = url;
			 _img.onload = function(){
				  $(".fotorama__img").attr("src",url);
				  $("#loading_image").hide();
				  $("#loading_image").remove();
			 };
        });
    });
//]]>
});
*/

