<?php
$con = mysqli_connect('localhost', 'root', '', 'php_data');

$name = $_POST['name'];
$email = $_POST['email'];

$query = "SELECT name,email FROM `users` WHERE name='$name' and email='$email'";
$result = mysqli_query($con, $query) or die(mysqli_error($con));
$count = mysqli_num_rows($result);
if ($count == 1){
echo "<button type='button' class='btn btn-success'>Logged In, Redirecting...</button>";
?>
<script>window.location.href = "welcome.php";</script>
<?php
}else{
echo "<button type='button' class='btn btn-danger'>Invalid Login Credentials!!!</button>";
}
?>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js"></script>
