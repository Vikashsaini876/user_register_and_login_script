<?php

if ( ! defined( 'ABSPATH' ) )
	exit;
	
class Licence_Key_Form{
	   
	   public function licence_key_field_form()
	   {
	            $validate = new Validate_Licence_Key();
				$result = $validate->validate_plugin_licence();
				?>
				<h2><?php _e('Activation Key', 'custom-plugin-development'); ?></h2>
				<div class="container">
				<br>
				   <img src="<?php echo plugins_url('/customplugin/images/development.png'); ?>" class="img-rounded center-block" alt="<?php _e('Plugin Development', 'custom-plugin-development'); ?>">
				   <br>
				   <h3><?php _e('Activate Plugin:', 'custom-plugin-development'); ?></h3>
				   <form method="POST">
					  <div class="form-group">
					     <!--label for="user">Test Input Box:</label-->
					      <input type="text" class="form-control" value="<?php if(!empty($result['activated_key_check'] === $result['activation_key_check'])) { echo $result['activated_key_check']; } ?>" id="activation_key" name="activation_key" placeholder="<?php _e('Your Activation Key', 'custom-plugin-development'); ?>">
					  </div>
					  <div class="form-group">
					      <input type="submit" class="btn btn-primary"  name="activate" value="<?php _e('Activate Plugin', 'custom-plugin-development'); ?>">
					  </div>
				  </form>
			    </div>
				<?php
	   } 
 	  
}
