<?php
/*
	Plugin Name: Custom Plugin Development
	Text Domain: custom-plugin-development
	Description: Custom WordPress Plugin with Classes, Namespaces, MVC pattern, Security and Kint debug library.
	Version: 1.0.0
*/

if ( ! defined( 'ABSPATH' ) )
	exit;
	
register_activation_hook( __FILE__, 'create_plugin_tables' );

function create_plugin_tables()
{      
	global $wpdb; 
	$db_table_name = $wpdb->prefix . 'custom_plugin_development';  // table name
	
	if( $wpdb->get_var("SHOW TABLES LIKE '$db_table_name'") != $db_table_name ) {
		$charset_collate = $wpdb->get_charset_collate();
		$sql = "CREATE TABLE $db_table_name ( id int(11) NOT NULL auto_increment, activation_key varchar(100) NOT NULL, activated varchar(100) NOT NULL, UNIQUE KEY id (id)) $charset_collate;";

		require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
		dbDelta( $sql );

		$insert_sql ="INSERT INTO `$db_table_name`(`activation_key`) VALUES ('E9E9F-9993432-45543')";
		dbDelta($insert_sql);
	}
}


/*...................... Load Classes ......................*/

require_once( 'autoload.php' );
require_once('core/views/admin-panel.php');
require_once('core/views/admin-notices.php');
require_once('core/views/licence-key-form.php');
require_once('core/models/validate-licence-key.php');

	
/*..................... Load CSS & JS Files .......................*/

// Include plugin stylesheet files
add_action( 'admin_init','add_styles');
function add_styles() {
    wp_register_style('stylesheet', plugins_url('/css/bootstrap.min.css',__FILE__ ));
    wp_enqueue_style('stylesheet');
}

// Include plugin script files
add_action( 'admin_init','add_scripts');
function add_scripts() {
    wp_register_script( 'js', plugins_url('/js/jquery.min.js',__FILE__ ));
    wp_enqueue_script('js');
	wp_register_script( 'js', plugins_url('/js/bootstrap.min.js',__FILE__ ));
    wp_enqueue_script('js');
}


// Create object of Plugin Class
$cwp = new Admin_Panel_Configuration();
$cwp = new Admin_Notices();


// Call and use namespace 
use customplugin\core\controllers\Kint_Debug_Library;
new Kint_Debug_Library();
