<?php
namespace Amasty\TextoverImages\Ui\DataProvider\Product\Form\Modifier;
use Magento\Catalog\Model\Locator\LocatorInterface;use Magento\Catalog\Ui\DataProvider\Product\Form\Modifier\AbstractModifier;use Magento\Ui\Component\Form\Fieldset;use Magento\Ui\Component\Form\Field;use Magento\Ui\Component\Form\Element\DataType\Text;use Magento\Ui\Component\Form\Element\Checkbox;use Magento\Store\Model\ScopeInterface;use Magento\Framework\Stdlib\ArrayManager;use Magento\Framework\App\Config\ScopeConfigInterface;

class NewField extends AbstractModifier
{
	 protected $scopeConfig;
	 protected $locator;
	 protected $arrayManager;	  
     public function __construct(
        LocatorInterface $locator,
        ArrayManager $arrayManager,
        ScopeConfigInterface $scopeConfig
    ) {
        $this->locator = $locator;
        $this->arrayManager = $arrayManager;
        $this->scopeConfig = $scopeConfig;
    }
	
    public function modifyData(array $data)
    {  
		$modelId = $this->locator->getProduct()->getId();
		
		if (!empty($modelId)){
			$objectManager = \Magento\Framework\App\ObjectManager::getInstance(); // Instance of object manager
			$resource = $objectManager->get('Magento\Framework\App\ResourceConnection');
			$connection = $resource->getConnection();
			$tableName = $resource->getTableName('textoverimage_config'); 
			
			$sql = "Select * FROM " . $tableName." WHERE product_id =$modelId";
			$result = $connection->fetchAll($sql);
			$data[$modelId][static::DATA_SOURCE_DEFAULT]['imgcreater'] = (array)@$result[0];
		}
        return $data;
    }
	
	public function modifyMeta(array $meta)
    {
		return $meta;
    }
}