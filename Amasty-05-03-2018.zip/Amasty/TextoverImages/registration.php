<?php
/**
 * @package Amasty_TextoverImages
 */
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Amasty_TextoverImages',
    __DIR__
);