<?php

namespace Amasty\TextoverImages\Observer;
use Magento\Framework\Event\Observer as EventObserver;
use Magento\Framework\Event\ObserverInterface;

class CheckoutCartProductAddAfterObserver implements ObserverInterface
{
    protected $_layout;
    protected $_storeManager;
    protected $_request;

    public function __construct(
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\View\LayoutInterface $layout,
        \Magento\Framework\App\RequestInterface $request
    ){
        $this->_layout = $layout;
        $this->_storeManager = $storeManager;
        $this->_request = $request;
    }
  
    public function execute(EventObserver $observer)
    {
		
        $item = $observer->getQuoteItem();
		
        $additionalOptions = array();
        if ($additionalOption = $item->getOptionByCode('additional_options'))
            $additionalOptions = (array) json_decode($additionalOption->getValue(),true);
        
        $instdata = $this->_request->getParam('instdata');
	  
		$custom_price = (float)@$instdata['custom_price'];
	  
		
	  
        if( !empty($instdata['username']))
        {
			$additionalOptions[] = [
				'label' => 'Instagram Username',
				'value' => trim($instdata['username'])
			];
	
            $item->addOption(array(
                'code' => 'additional_options',
                'value' => json_encode($additionalOptions)
            ));
			
			if( $custom_price > 0 ){ 
				$price =$item->getProduct()->getPrice() + $custom_price;			
				$item->setCustomPrice($price);			
				$item->setOriginalCustomPrice($price);
			}
						
			//	$item->getProduct()->setIsSuperMode(true);			
			
        }
     
    }
}