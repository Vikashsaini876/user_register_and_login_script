<?php


namespace Amasty\TextoverImages\Setup;

	use Magento\Framework\Setup\InstallSchemaInterface;
    use Magento\Framework\Setup\ModuleContextInterface;
    use Magento\Framework\Setup\SchemaSetupInterface;
    use Magento\Framework\DB\Ddl\Table;
     

class InstallSchema implements InstallSchemaInterface
{
    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
         $installer = $setup;
            $installer->startSetup();
     
            // Get tutorial_simplenews table
            $tableName = $installer->getTable('textoverimage_config');
            // Check if the table already exists
            if ($installer->getConnection()->isTableExists($tableName) != true) {
                // Create tutorial_simplenews table
                $table = $installer->getConnection()
                    ->newTable($tableName)
            ->addColumn(
                'product_id',
                \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                null,
                ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
                'product_id'
            )
            ->addColumn(
                'enable',
                \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                null,
               ['nullable' => false, 'default' => ''],
                'enable'
            )
            ->addColumn(
                'wrap_width',
                \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                null,
                ['unsigned' => true, 'nullable' => false],
                'wrap_width'
            )
			 ->addColumn(
                'left_pos',
                \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                null,
                ['unsigned' => true, 'nullable' => false],
                'left_pos'
            )
			
			->setComment('News Table')
            ->setOption('type', 'InnoDB')
            ->setOption('charset', 'utf8_general_ci');
            $installer->getConnection()->createTable($table);
		}	
         $installer->endSetup();
    }
}
