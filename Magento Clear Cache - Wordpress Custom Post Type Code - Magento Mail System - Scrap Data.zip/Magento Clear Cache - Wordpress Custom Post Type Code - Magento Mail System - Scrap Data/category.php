<?php
/*  ----------------------------------------------------------------------------
    the blog index template
 */

get_header();

global $loop_module_id, $loop_sidebar_position;

$current_category_id = get_query_var('cat');
$current_category_obj = get_category($current_category_id);
$cat_id = $current_category_obj->cat_ID;	

?>
<div class="td-main-content-wrap td-main-page-wrap td-container-wrap">
	<div class="tdc-content-wrap">
	<div id="td_uid_1_5b55c62214b1b" class="tdc-row">
		<div id="div_postion_row_id" class="vc_row td-ss-row wpb_row td-pb-row category_page_div">
			<div class="vc_column left_side_div_id wpb_column vc_column_container tdc-column td-pb-span8">
				<div class="wpb_wrapper">
			
					<!-- Block Num 14 Four  Start -->
					<div class="td_block_wrap td_block_14 td-pb-full-cell td-pb-border-top second_row_img td_block_template_14 td-column-2">
						<div id="td_uid_6_5b55aa0084c65" class="td_block_inner td-column-2">
						
							<div class="td-block-row">
							
							<?php
		                     
							$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
							$limit = 7;
							$offset = ( $limit * $paged ) - $limit;
							$atts['pages'] = $paged; 
							$atts['post-type'] = 'post'; 
							$atts['orderby'] = 'date'; 
							$atts['order'] = 'DESC';
							$atts['offset'] = $offset; 
							$atts['posts_per_page'] = $limit; 
							$atts['category'] =  array($cat_id);
							$result = new WP_Query($atts);
							$post_res = $result->posts;
                            $count = 1;							
								foreach($post_res as $post){
							
								$post_id = $post->ID;
								$post_title = $post->post_title;
								//$post_name = $post->post_name;
								//var_dump($post);
								$post_content = $post->post_content;
								$post_date = $post->post_date;
								$post_page = $post->paged;				
								$thumbnail_id = get_post_meta( $post_id, '_thumbnail_id', true );
								$image_name = get_post_meta( $thumbnail_id, '_wp_attached_file', true );
								$up_dir = wp_upload_dir();
								$up_dir_url = $up_dir['baseurl'];
								$image_url = $up_dir_url.'/'.$image_name;
								if(strlen($post_content) > 250){
									$short_description = substr($post_content,0,250);	
								}
								else{
									
									$short_description = $post_content;
								}
								
								$des = strip_tags($short_description);
								//var_dump($des);
							   if($count == 1){
								   $add_class ="first_top_post";
							   }
								else{
									$add_class = false;
								}
								?>
								
								<div class="td-block-span6 <?php echo $add_class; ?>">
									<div class="td_module_mx1 td_module_wrap td-animation-stack td-meta-info-hide">
										<div class="td-module-thumb">
											<a href="<?php echo get_post_permalink($post_id); ?>" rel="bookmark" title="<?php echo $post_title; ?>">
												<img class="entry-thumb td-animation-stack-type0-1" src="<?php echo $image_url; ?>" alt="<?php echo $post_title; ?>" title="<?php echo $post_title; ?>" width="356" height="220">
											</a>
										</div>
										<div class="td-module-meta-info">
											<h3 class="entry-title td-module-title">
												<a href="<?php echo get_post_permalink($post_id); ?>" rel="bookmark" title="<?php echo $post_title; ?>"><?php echo $post_title; ?></a>
											</h3>
											<?php if($count == 1){ ?>
											<div class="td-excerpt shortdes"> <?php echo $des; ?> </div>
											
											<?php
											}?>
												
										</div>

									</div>
								</div>
								<?php if($count == 3){ ?>
									<div class="pz_cont paszone-container-672   " id="paszonecont_673" style="">
									<div class="pasinfotxt above">
									<small style="font-size:11px; color:#C0C0C0; text-decoration:none;"></small>
									</div>
									<div class="wppaszone paszone-673 " id="673" style="">
									<div class="wppasrotate   paszoneholder-673" style="">
									<div class="pasli pasli-997 " data-duration="5000" bid="997" aid="673">
									<a class="wppaslink" href="https://eyjafrettir.is?pasID=OTk3&amp;pasZONE=Njcz" target="_blank">
									<img src="https://eyjafrettir.is/wp-content/uploads/2018/06/Husasmidjan.jpg?pas=2988497501807231212" alt="Húsasmiðjan – almenn auglýsing" border="0"></a>
									</div>
									</div>
									</div>
									</div>
									
								<?php }	?>
								<?php if($count == 7){ ?>
									<div class="pz_cont paszone-container-673   " id="paszonecont_673" style="max-width:720px;   ">
									<div class="pasinfotxt above">
									<small style="font-size:11px; color:#C0C0C0; text-decoration:none;"></small>
									</div>
									<div class="wppaszone paszone-673 " id="673" style="max-width:720px; max-height:210px;  ">
									<div class="wppasrotate   paszoneholder-673" style="">
									<div class="pasli pasli-997 " data-duration="5000" bid="997" aid="673">
									<a class="wppaslink" href="https://eyjafrettir.is?pasID=OTk3&amp;pasZONE=Njcz" target="_blank">
									<img src="https://eyjafrettir.is/wp-content/uploads/2018/06/Husasmidjan.jpg?pas=2988497501807231212" alt="Húsasmiðjan – almenn auglýsing" border="0"></a>
									</div>
									</div>
									</div>
									</div>
									
								<?php }	?>
								
								<?php
								$count++;
								} 	?>
								<ul class="pagination" style="width:100%; float:left;">
									<li id="previous-posts" style="float:left">
										<?php previous_posts_link( '<< Previous', $result->max_num_pages ); ?>
									</li>
									<li id="next-posts" style="float:right">
										<?php next_posts_link( 'Next >>', $result->max_num_pages ); ?>
									</li>
								</ul>
								
							<?php wp_reset_query(); ?>
								

							</div>
						</div>
				    </div>
					<!-- Block Num 14 Four  End -->
					
			</div>
		</div>	
		<div class="vc_column right_side_div_id wpb_column vc_column_container tdc-column td-pb-span4">
				
			<?php dynamic_sidebar('td_demo_category ');?>
		</div>
		
		</div>
	</div>
</div>
</div>

<?php

get_footer();
?>