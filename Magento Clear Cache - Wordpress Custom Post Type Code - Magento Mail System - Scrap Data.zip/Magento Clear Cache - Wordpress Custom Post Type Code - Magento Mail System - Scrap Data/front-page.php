<?php
/**
 * Template Name: 	Home Page
 * Stash Theme: Home page for site or blog
 * @package WordPress
 * @subpackage Stash Theme
 * @since 1.0
 */
get_header();
?>
		<div class="container">
			
			<?php
			function homepage_postrow_First(){
				
			?>
			<div class="col-md-12 col-sm-12 col-xl-12 slider-sec">
                 
				<div class="post-inner sec"> 
				
					<?php
					$args = array(
						'orderby' => 'post_modified',
						'order' => 'DESC', 
						'post_type'   => 'post',
						'post_status'   => 'publish',
						'posts_per_page'   => 4,
						'offset' => 0
					);

					$all_posts = get_posts( $args );
					
					
					// last updated
					function get_post_updates_time1( $ptime )
					{
					$estimate_time = time() - $ptime;

					if( $estimate_time < 1 )
					{
					return 'less than 1 second ago';
					}

					$condition = array( 
							12 * 30 * 24 * 60 * 60  =>  'year',
							30 * 24 * 60 * 60       =>  'month',
							24 * 60 * 60            =>  'day',
							60 * 60                 =>  'hr',
							60                      =>  'min',
							1                       =>  'sec'
					);

					foreach( $condition as $secs => $str )
					{
					$d = $estimate_time / $secs;

					if( $d >= 1 )
					{
						$r = round( $d );
						return 'Updated ' . $r . ' ' . $str . ( $r > 1 ? 's' : '' ) . ' ago';
					}
					}
					}
					?>
					
					<?php foreach($all_posts as $post_data) { 
					$post_id = $post_data ->ID;
					$post_content = $post_data ->post_content;
					$post_modified = $post_data ->post_modified;
					
					
					$img_id = get_post_meta($post_id,'_thumbnail_id',true);
					$img_url = get_post_meta($img_id,'_wp_attached_file',true);
					$category = get_the_category($post_id);
					$cat_name = $category[0]->name;
					if(strlen($post_content) > 51){
						$post_content=substr($post_content,0,51); 
					}
					else{
						$post_content=$post_content;
					}
					
					
					
					?> 
					
						<div class="col-md-3 col-sm-6 col-xs-12 colume">
							<a href="<?php echo get_post_permalink($post_id); ?>"><img class="img-responsive" src="wp-content/uploads/<?php echo $img_url; ?>"></a>
							<div class="text">    
								<p><a href="<?php echo get_post_permalink($post_id); ?>"><?php echo $post_content ;?></a></p>
								<span>
								<?php
								$get_slug1 = wp_get_object_terms($post_id,'category');
								foreach ( $get_slug1 as $use_slug1){
								?>
								<a href="category/<?php echo $use_slug1->slug; ?>"><?php echo $cat_name; ?></a>
								<?php
								}
				      		    ?>
								- <?php $timeago = get_post_updates_time1(strtotime($post_modified));
                                echo $timeago; ?></span>
								<a href="<?php echo get_post_permalink($post_id); ?>"><img src="wp-content/uploads/2018/05/arow.png"></a>
							</div> 
						</div> 
						
					<?php } ?>
						
						
						
					
					
				</div>  
				
                   
			</div>
			<?php
			}
			add_shortcode( 'homepage_postrow_one', 'homepage_postrow_First' ); ?>
		
		<?php
		function homepage_postrow_Second(){
				
		?>			
			<div class="col-md-12 col-sm-12 col-xl-12 slider-sec">
                 
				<div class="post-inner sec">   
				
					<?php
					$args = array(
						'category' => 0, 
						'orderby' => 'post_modified',
						'order' => 'DESC', 
						'post_type'   => 'post',
						'post_status'   => 'publish',
						'posts_per_page'   => 4,
						'offset' => 4
						
					);

					$all_posts = get_posts( $args );
					
					// last updated
					function get_post_updates_time2( $ptime )
					{
					$estimate_time = time() - $ptime;

					if( $estimate_time < 1 )
					{
					return 'less than 1 second ago';
					}

$condition = array( 
							12 * 30 * 24 * 60 * 60  =>  'year',
							30 * 24 * 60 * 60       =>  'month',
							24 * 60 * 60            =>  'day',
							60 * 60                 =>  'hr',
							60                      =>  'min',
							1                       =>  'sec'
					);

					foreach( $condition as $secs => $str )
					{
					$d = $estimate_time / $secs;

					if( $d >= 1 )
					{
						$r = round( $d );
						return 'Updated ' . $r . ' ' . $str . ( $r > 1 ? 's' : '' ) . ' ago';
					}
					}
					}
					
					

					?>
					
					<?php foreach($all_posts as $post_data) { 
					$post_id = $post_data ->ID;
					$post_content = $post_data ->post_content;
					$post_modified = $post_data ->post_modified;
					$img_id = get_post_meta($post_id,'_thumbnail_id',true);
					$img_url = get_post_meta($img_id,'_wp_attached_file',true);
					$category = get_the_category($post_id);
					$cat_name = $category[0]->name;
					if(strlen($post_content) > 51){
						$post_content=substr($post_content,0,51);
					}
					else{
						$post_content=$post_content;
					}
					
					?> 
					
						<div class="col-md-3 col-sm-6 col-xs-12 colume">
							<a href="<?php echo get_post_permalink($post_id); ?>"><img class="img-responsive" src="wp-content/uploads/<?php echo $img_url; ?>"></a>
							<div class="text">    
								<p><a href="<?php echo get_post_permalink($post_id); ?>"><?php echo $post_content ;?></a></p>
							    <span>
								<?php
								$get_slug2 = wp_get_object_terms($post_id,'category');
								foreach ( $get_slug2 as $use_slug2){
								?>
								<a href="category/<?php echo $use_slug2->slug; ?>"><?php echo $cat_name; ?></a>
								<?php
								}
				      		    ?>
								<!--—-->- <?php $timeago = get_post_updates_time2(strtotime($post_modified));
                                echo $timeago; ?></span>
								<a href="<?php echo get_post_permalink($post_id); ?>"><img src="wp-content/uploads/2018/05/arow.png"></a>
							</div> 
						</div> 
						
					<?php } ?>
						
						
						
					
					
				</div>  
				                   
			</div>
		</div>
		<?php
		}
		add_shortcode( 'homepage_postrow_two', 'homepage_postrow_Second' );
		?>
		
		<?php while ( have_posts() ) : the_post(); ?>
		<?php the_content(); ?>
		<?php endwhile; ?>
		
<?php 
get_footer();
?>