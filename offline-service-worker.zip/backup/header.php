<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<link rel="manifest" href="https://zyppapp.com/momsnacks/wp-content/themes/restaurant-and-cafe/manifest.json">
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale = 1.0, maximum-scale=1.0, user-scalable=no">

<link rel="profile" href="http://gmpg.org/xfn/11">
<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
<link href="https://zyppapp.com/momsnacks/wp-content/themes/restaurant-and-cafe/css/iconsmind.css" rel="stylesheet" type="text/css" media="all" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/simple-line-icons/2.4.1/css/simple-line-icons.css">

<link href="https://zyppapp.com/momsnacks/wp-content/themes/restaurant-and-cafe/css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
       
        <link href="https://zyppapp.com/momsnacks/wp-content/themes/restaurant-and-cafe/css/theme.css" rel="stylesheet" type="text/css" media="all" />
        <link href="https://zyppapp.com/momsnacks/wp-content/themes/restaurant-and-cafe/css/custom.css" rel="stylesheet" type="text/css" media="all" />
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:200,300,400,400i,500,600,700" rel="stylesheet">	
		
<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<div id="page" class="site">
	
	<header id="masthead" class="site-header <?php if( !is_page_template( 'template-home.php' ) ) { esc_attr_e( 'header-inner', 'restaurant-and-cafe' ); }  ?>" role="banner">
		<div class = "container">
			                            <div class="col-md-1 col-sm-2 col-xs-3">
                                <div class="bar__module">
                                   <div class="site-branding">
		<?php 
			 if( function_exists( 'has_custom_logo' ) && has_custom_logo() ){
               	the_custom_logo();
             } 

        ?>
            <h1 class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></h1>
			<?php

			$description = get_bloginfo( 'description', 'display' );
			if ( $description || is_customize_preview() ) : ?>
				<p class="site-description"><?php echo esc_html( $description ); /* WPCS: xss ok. */ ?></p>
			<?php
			endif; ?>
		</div><!-- .site-branding -->
			
                                </div>
                            </div>
		<!--div id="mobile-header">
			    <a id="responsive-menu-button" href="#sidr-main">
			    	<span class="fa fa-navicon"></span>
			    </a>
			</div-->
			
			 <div class="col-md-11 col-sm-10 col-xs-9">
                                <div class="bar__module">
                                    <div class="modal-instance pull-right">
                                        <a class="modal-trigger menu-toggle" href="#"> <span class="fa fa-navicon"></span> </a>
                                        <div class="modal-container menu-fullscreen">
                                            <div class="modal-content" data-width="100%" data-height="100%">
                                                                                             
                                              <nav id="site-navigation" class="main-navigation" role="navigation">
			<div>
			<?php wp_nav_menu( array( 'theme_location' => 'primary', 'menu_id' => 'primary-menu' ) ); ?>
			</div>
		</nav><!-- #site-navigation -->
                                              
                                               </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
			
			
			
		
		</div>
	</header><!-- #masthead -->

  	<?php 
  	$restaurant_and_cafe_ed_breadcrumb = get_theme_mod( 'restaurant_and_cafe_ed_breadcrumb' );
   		if( ! ( is_page_template( 'template-home.php' ) || is_404() ) && (true == $restaurant_and_cafe_ed_breadcrumb)   ) { ?>

			<div class="breadcrumbs">
				<div class="container">
					<?php do_action( 'restaurant_and_cafe_breadcrumbs' ); ?>
				</div>
			</div>
   	
	<?php } ?>
	<?php 
	 	if( !is_page_template( 'template-home.php' ) ) {
echo '<div><div id="content" class="site-content"><div class = "row">';
		} ?>
