<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Restaurant_and_Cafe
 */

?>
		</div>
	</div><!-- #content -->
</div>

	<footer id="colophon" class="site-footer" role="contentinfo">
      		<div class="widget-area">
				<div class="container">
					<div class="footer-t">
                        <div class="row">
					   <?php 
                            echo '<div class= "col-12">';
                                if( is_active_sidebar( 'footer-widget-one') ) dynamic_sidebar( 'footer-widget-one' ); 
                            echo '</div>';
                        ?>
                        <?php /*
                            echo '<div class= "col-3">';
                                if( is_active_sidebar( 'footer-widget-two') ) dynamic_sidebar( 'footer-widget-two' ); 
                            echo '</div>';
                        ?>
                        <?php 
                            echo '<div class= "col-3">';
                                if( is_active_sidebar( 'footer-widget-three') ) dynamic_sidebar( 'footer-widget-three' ); 
                            echo '</div>';
                       */ ?>
                    </div>
				</div>
			</div>	
		</div>
        <?php //do_action( 'restaurant_and_cafe_footer' ); ?>
		
	</footer><!-- #colophon -->

</div><!-- #page -->

<?php wp_footer(); ?>

        <!--script src="https://zyppapp.com/momsnacks/wp-content/themes/restaurant-and-cafe/js/jquery-3.1.1.min.js"></script-->
        <script src="https://zyppapp.com/momsnacks/wp-content/themes/restaurant-and-cafe/js/jquery-ui.js"></script>  
        <script src="https://zyppapp.com/momsnacks/wp-content/themes/restaurant-and-cafe/js/scripts.js"></script>  
        <script src="https://zyppapp.com/momsnacks/wp-content/themes/restaurant-and-cafe/js/flickity.min.js"></script>
        <!--script src="https://zyppapp.com/momsnacks/wp-content/themes/restaurant-and-cafe/js/parallax.js"></script-->
        <script src="https://zyppapp.com/momsnacks/wp-content/themes/restaurant-and-cafe/js/ytplayer.min.js"></script>
        <script src="https://zyppapp.com/momsnacks/wp-content/themes/restaurant-and-cafe/js/granim.min.js"></script>
        <script src="https://zyppapp.com/momsnacks/wp-content/themes/restaurant-and-cafe/js/countdown.min.js"></script>
        <script src="https://zyppapp.com/momsnacks/wp-content/themes/restaurant-and-cafe/js/smooth-scroll.min.js"></script>

        
        
        
        
        <script src="https://zyppapp.com/momsnacks/wp-content/themes/restaurant-and-cafe/js/addtohomescreen.min.js"></script>
        <script src="https://zyppapp.com/momsnacks/wp-content/themes/restaurant-and-cafe/js/custom.js"></script>     
        <script src="https://zyppapp.com/momsnacks/wp-content/themes/restaurant-and-cafe/js/customizer.js"></script>
        <script src="https://zyppapp.com/momsnacks/wp-content/themes/restaurant-and-cafe/js/datepicker.js"></script>   
        <script src="https://zyppapp.com/momsnacks/wp-content/themes/restaurant-and-cafe/js/isotope.min.js"></script>
        <script src="https://zyppapp.com/momsnacks/wp-content/themes/restaurant-and-cafe/js/easypiechart.min.js"></script>   
        <script src="https://zyppapp.com/momsnacks/wp-content/themes/restaurant-and-cafe/js/jquery.sidr.js"></script>
        <script src="https://zyppapp.com/momsnacks/wp-content/themes/restaurant-and-cafe/js/lightbox.min.js"></script>
        <script src="https://zyppapp.com/momsnacks/wp-content/themes/restaurant-and-cafe/js/lightslider.js"></script>   
        <script src="https://zyppapp.com/momsnacks/wp-content/themes/restaurant-and-cafe/js/spectragram.min.js"></script>
        <script src="https://zyppapp.com/momsnacks/wp-content/themes/restaurant-and-cafe/js/twitterfetcher.min.js"></script>  
        <script src="https://zyppapp.com/momsnacks/wp-content/themes/restaurant-and-cafe/js/typed.min.js"></script>

  <main style="text-align:center">
      <button style="margin-top:10px;" disabled class="js-push-btn mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect">
        Enable Push Messaging
      </button>
    <section class="subscription-details js-subscription-details is-invisible">
      <p>Once you've subscribed your user, you'd send their subscription to your
      server to store in a database so that when you want to send a message
      you can lookup the subscription and send a message to it.</p>
      <p>To simplify things for this code lab copy the following details
      into the <a href="https://web-push-codelab.appspot.com/">Push Companion
      Site</a> and it'll send a push message for you, using the application
      server keys on the site - so make sure they match.</p>
      <pre><code class="js-subscription-json"></code></pre>
    </section>
  </main>

  <script src="https://zyppapp.com/momsnacks/app/scripts/main.js"></script>

  <script src="https://code.getmdl.io/1.2.1/material.min.js"></script>
<script src="https://zyppapp.com/momsnacks/wp-content/themes/restaurant-and-cafe/offlinejs/global.js"></script>
		 
<script>
jQuery(".woocommerce-message").delay(4000).fadeOut();
</script>
</body>
</html>
