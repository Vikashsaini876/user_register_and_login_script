<?php
include('conn.php');


?>


<!DOCTYPE html>

<html lang="en"><head>
    
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="http://getbootstrap.com/favicon.ico">
    <title>OccupationWise</title>
    <link rel="stylesheet" href="OccupationWise_files/bootstrap.css" media="screen" title="no title" charset="utf-8">
    <link rel="stylesheet" href="OccupationWise_files/custom.css" media="screen" title="no title" charset="utf-8">
    <link href="OccupationWise_files/css.css" rel="stylesheet">

    <script>
      if (!Modernizr.svg) {
        $('img[src$=".svg"]').each(function()
        {
            $(this).attr('src', $(this).attr('src').replace('.svg', '.png'));
        });
      }
    </script>

  <style charset="utf-8" type="text/css" class="firebugResetStyles">/* See license.txt for terms of usage */

/** reset styling **/

.firebugResetStyles {

    z-index: 2147483646 !important;

    top: 0 !important;

    left: 0 !important;

    display: block !important;

    border: 0 none !important;

    margin: 0 !important;

    padding: 0 !important;

    outline: 0 !important;

    min-width: 0 !important;

    max-width: none !important;

    min-height: 0 !important;

    max-height: none !important;

    position: fixed !important;

    transform: rotate(0deg) !important;

    transform-origin: 50% 50% !important;

    border-radius: 0 !important;

    box-shadow: none !important;

    background: transparent none !important;

    pointer-events: none !important;

    white-space: normal !important;

}

style.firebugResetStyles {

    display: none !important;

}



.firebugBlockBackgroundColor {

    background-color: transparent !important;

}



.firebugResetStyles:before, .firebugResetStyles:after {

    content: "" !important;

}

/**actual styling to be modified by firebug theme**/

.firebugCanvas {

    display: none !important;

}



/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

.firebugLayoutBox {

    width: auto !important;

    position: static !important;

}



.firebugLayoutBoxOffset {

    opacity: 0.8 !important;

    position: fixed !important;

}



.firebugLayoutLine {

    opacity: 0.4 !important;

    background-color: #000000 !important;

}



.firebugLayoutLineLeft, .firebugLayoutLineRight {

    width: 1px !important;

    height: 100% !important;

}



.firebugLayoutLineTop, .firebugLayoutLineBottom {

    width: 100% !important;

    height: 1px !important;

}



.firebugLayoutLineTop {

    margin-top: -1px !important;

    border-top: 1px solid #999999 !important;

}



.firebugLayoutLineRight {

    border-right: 1px solid #999999 !important;

}



.firebugLayoutLineBottom {

    border-bottom: 1px solid #999999 !important;

}



.firebugLayoutLineLeft {

    margin-left: -1px !important;

    border-left: 1px solid #999999 !important;

}



/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

.firebugLayoutBoxParent {

    border-top: 0 none !important;

    border-right: 1px dashed #E00 !important;

    border-bottom: 1px dashed #E00 !important;

    border-left: 0 none !important;

    position: fixed !important;

    width: auto !important;

}



.firebugRuler{

    position: absolute !important;

}



.firebugRulerH {

    top: -15px !important;

    left: 0 !important;

    width: 100% !important;

    height: 14px !important;

    background: url("data:image/png,%89PNG%0D%0A%1A%0A%00%00%00%0DIHDR%00%00%13%88%00%00%00%0E%08%02%00%00%00L%25a%0A%00%00%00%04gAMA%00%00%D6%D8%D4OX2%00%00%00%19tEXtSoftware%00Adobe%20ImageReadyq%C9e%3C%00%00%04%F8IDATx%DA%EC%DD%D1n%E2%3A%00E%D1%80%F8%FF%EF%E2%AF2%95%D0D4%0E%C1%14%B0%8Fa-%E9%3E%CC%9C%87n%B9%81%A6W0%1C%A6i%9A%E7y%0As8%1CT%A9R%A5J%95*U%AAT%A9R%A5J%95*U%AAT%A9R%A5J%95*U%AAT%A9R%A5J%95*U%AAT%A9R%A5J%95*U%AAT%A9R%A5J%95*U%AAT%A9R%A5J%95*U%AATE9%FE%FCw%3E%9F%AF%2B%2F%BA%97%FDT%1D~K(%5C%9D%D5%EA%1B%5C%86%B5%A9%BDU%B5y%80%ED%AB*%03%FAV9%AB%E1%CEj%E7%82%EF%FB%18%BC%AEJ8%AB%FA'%D2%BEU9%D7U%ECc0%E1%A2r%5DynwVi%CFW%7F%BB%17%7Dy%EACU%CD%0E%F0%FA%3BX%FEbV%FEM%9B%2B%AD%BE%AA%E5%95v%AB%AA%E3E5%DCu%15rV9%07%B5%7F%B5w%FCm%BA%BE%AA%FBY%3D%14%F0%EE%C7%60%0EU%AAT%A9R%A5J%95*U%AAT%A9R%A5J%95*U%AAT%A9R%A5J%95*U%AAT%A9R%A5J%95*U%AAT%A9R%A5JU%88%D3%F5%1F%AE%DF%3B%1B%F2%3E%DAUCNa%F92%D02%AC%7Dm%F9%3A%D4%F2%8B6%AE*%BF%5C%C2Ym~9g5%D0Y%95%17%7C%C8c%B0%7C%18%26%9CU%CD%13i%F7%AA%90%B3Z%7D%95%B4%C7%60%E6E%B5%BC%05%B4%FBY%95U%9E%DB%FD%1C%FC%E0%9F%83%7F%BE%17%7DkjMU%E3%03%AC%7CWj%DF%83%9An%BCG%AE%F1%95%96yQ%0Dq%5Dy%00%3Et%B5'%FC6%5DS%95pV%95%01%81%FF'%07%00%00%00%00%00%00%00%00%00%F8x%C7%F0%BE%9COp%5D%C9%7C%AD%E7%E6%EBV%FB%1E%E0(%07%E5%AC%C6%3A%ABi%9C%8F%C6%0E9%AB%C0'%D2%8E%9F%F99%D0E%B5%99%14%F5%0D%CD%7F%24%C6%DEH%B8%E9rV%DFs%DB%D0%F7%00k%FE%1D%84%84%83J%B8%E3%BA%FB%EF%20%84%1C%D7%AD%B0%8E%D7U%C8Y%05%1E%D4t%EF%AD%95Q%BF8w%BF%E9%0A%BF%EB%03%00%00%00%00%00%00%00%00%00%B8vJ%8E%BB%F5%B1u%8Cx%80%E1o%5E%CA9%AB%CB%CB%8E%03%DF%1D%B7T%25%9C%D5(%EFJM8%AB%CC'%D2%B2*%A4s%E7c6%FB%3E%FA%A2%1E%80~%0E%3E%DA%10x%5D%95Uig%15u%15%ED%7C%14%B6%87%A1%3B%FCo8%A8%D8o%D3%ADO%01%EDx%83%1A~%1B%9FpP%A3%DC%C6'%9C%95gK%00%00%00%00%00%00%00%00%00%20%D9%C9%11%D0%C0%40%AF%3F%EE%EE%92%94%D6%16X%B5%BCMH%15%2F%BF%D4%A7%C87%F1%8E%F2%81%AE%AAvzr%DA2%ABV%17%7C%E63%83%E7I%DC%C6%0Bs%1B%EF6%1E%00%00%00%00%00%00%00%00%00%80cr%9CW%FF%7F%C6%01%0E%F1%CE%A5%84%B3%CA%BC%E0%CB%AA%84%CE%F9%BF)%EC%13%08WU%AE%AB%B1%AE%2BO%EC%8E%CBYe%FE%8CN%ABr%5Dy%60~%CFA%0D%F4%AE%D4%BE%C75%CA%EDVB%EA(%B7%F1%09g%E5%D9%12%00%00%00%00%00%00%00%00%00H%F6%EB%13S%E7y%5E%5E%FB%98%F0%22%D1%B2'%A7%F0%92%B1%BC%24z3%AC%7Dm%60%D5%92%B4%7CEUO%5E%F0%AA*%3BU%B9%AE%3E%A0j%94%07%A0%C7%A0%AB%FD%B5%3F%A0%F7%03T%3Dy%D7%F7%D6%D4%C0%AAU%D2%E6%DFt%3F%A8%CC%AA%F2%86%B9%D7%F5%1F%18%E6%01%F8%CC%D5%9E%F0%F3z%88%AA%90%EF%20%00%00%00%00%00%00%00%00%00%C0%A6%D3%EA%CFi%AFb%2C%7BB%0A%2B%C3%1A%D7%06V%D5%07%A8r%5D%3D%D9%A6%CAu%F5%25%CF%A2%99%97zNX%60%95%AB%5DUZ%D5%FBR%03%AB%1C%D4k%9F%3F%BB%5C%FF%81a%AE%AB'%7F%F3%EA%FE%F3z%94%AA%D8%DF%5B%01%00%00%00%00%00%00%00%00%00%8E%FB%F3%F2%B1%1B%8DWU%AAT%A9R%A5J%95*U%AAT%A9R%A5J%95*U%AAT%A9R%A5J%95*U%AAT%A9R%A5J%95*U%AAT%A9R%A5J%95*U%AAT%A9R%A5J%95*U%AAT%A9R%A5J%95*UiU%C7%BBe%E7%F3%B9%CB%AAJ%95*U%AAT%A9R%A5J%95*U%AAT%A9R%A5J%95*U%AAT%A9R%A5J%95*U%AAT%A9R%A5J%95*U%AAT%A9R%A5J%95*U%AAT%A9R%A5J%95*U%AAT%A9R%A5*%AAj%FD%C6%D4%5Eo%90%B5Z%ADV%AB%D5j%B5Z%ADV%AB%D5j%B5Z%ADV%AB%D5j%B5Z%ADV%AB%D5j%B5Z%ADV%AB%D5j%B5Z%ADV%AB%D5j%B5Z%ADV%AB%D5j%B5%86%AF%1B%9F%98%DA%EBm%BBV%AB%D5j%B5Z%ADV%AB%D5j%B5Z%ADV%AB%D5j%B5Z%ADV%AB%D5j%B5Z%ADV%AB%D5j%B5Z%ADV%AB%D5j%B5Z%ADV%AB%D5j%B5Z%AD%D6%E4%F58%01%00%00%00%00%00%00%00%00%00%00%00%00%00%40%85%7F%02%0C%008%C2%D0H%16j%8FX%00%00%00%00IEND%AEB%60%82") repeat-x !important;

    border-top: 1px solid #BBBBBB !important;

    border-right: 1px dashed #BBBBBB !important;

    border-bottom: 1px solid #000000 !important;

}



.firebugRulerV {

    top: 0 !important;

    left: -15px !important;

    width: 14px !important;

    height: 100% !important;

    background: url("data:image/png,%89PNG%0D%0A%1A%0A%00%00%00%0DIHDR%00%00%00%0E%00%00%13%88%08%02%00%00%00%0E%F5%CB%10%00%00%00%04gAMA%00%00%D6%D8%D4OX2%00%00%00%19tEXtSoftware%00Adobe%20ImageReadyq%C9e%3C%00%00%06~IDATx%DA%EC%DD%D1v%A20%14%40Qt%F1%FF%FF%E4%97%D9%07%3BT%19%92%DC%40(%90%EEy%9A5%CB%B6%E8%F6%9Ac%A4%CC0%84%FF%DC%9E%CF%E7%E3%F1%88%DE4%F8%5D%C7%9F%2F%BA%DD%5E%7FI%7D%F18%DDn%BA%C5%FB%DF%97%BFk%F2%10%FF%FD%B4%F2M%A7%FB%FD%FD%B3%22%07p%8F%3F%AE%E3%F4S%8A%8F%40%EEq%9D%BE8D%F0%0EY%A1Uq%B7%EA%1F%81%88V%E8X%3F%B4%CEy%B7h%D1%A2E%EBohU%FC%D9%AF2fO%8BBeD%BE%F7X%0C%97%A4%D6b7%2Ck%A5%12%E3%9B%60v%B7r%C7%1AI%8C%BD%2B%23r%00c0%B2v%9B%AD%CA%26%0C%1Ek%05A%FD%93%D0%2B%A1u%8B%16-%95q%5Ce%DCSO%8E%E4M%23%8B%F7%C2%FE%40%BB%BD%8C%FC%8A%B5V%EBu%40%F9%3B%A72%FA%AE%8C%D4%01%CC%B5%DA%13%9CB%AB%E2I%18%24%B0n%A9%0CZ*Ce%9C%A22%8E%D8NJ%1E%EB%FF%8F%AE%CAP%19*%C3%BAEKe%AC%D1%AAX%8C*%DEH%8F%C5W%A1e%AD%D4%B7%5C%5B%19%C5%DB%0D%EF%9F%19%1D%7B%5E%86%BD%0C%95%A12%AC%5B*%83%96%CAP%19%F62T%86%CAP%19*%83%96%CA%B8Xe%BC%FE)T%19%A1%17xg%7F%DA%CBP%19*%C3%BA%A52T%86%CAP%19%F62T%86%CA%B0n%A9%0CZ%1DV%C6%3D%F3%FCH%DE%B4%B8~%7F%5CZc%F1%D6%1F%AF%84%F9%0F6%E6%EBVt9%0E~%BEr%AF%23%B0%97%A12T%86%CAP%19%B4T%86%CA%B8Re%D8%CBP%19*%C3%BA%A52huX%19%AE%CA%E5%BC%0C%7B%19*CeX%B7h%A9%0C%95%E1%BC%0C%7B%19*CeX%B7T%06%AD%CB%5E%95%2B%BF.%8F%C5%97%D5%E4%7B%EE%82%D6%FB%CF-%9C%FD%B9%CF%3By%7B%19%F62T%86%CA%B0n%D1R%19*%A3%D3%CA%B0%97%A12T%86uKe%D0%EA%B02*%3F1%99%5DB%2B%A4%B5%F8%3A%7C%BA%2B%8Co%7D%5C%EDe%A8%0C%95a%DDR%19%B4T%C66%82fA%B2%ED%DA%9FC%FC%17GZ%06%C9%E1%B3%E5%2C%1A%9FoiB%EB%96%CA%A0%D5qe4%7B%7D%FD%85%F7%5B%ED_%E0s%07%F0k%951%ECr%0D%B5C%D7-g%D1%A8%0C%EB%96%CA%A0%A52T%C6)*%C3%5E%86%CAP%19%D6-%95A%EB*%95q%F8%BB%E3%F9%AB%F6%E21%ACZ%B7%22%B7%9B%3F%02%85%CB%A2%5B%B7%BA%5E%B7%9C%97%E1%BC%0C%EB%16-%95%A12z%AC%0C%BFc%A22T%86uKe%D0%EA%B02V%DD%AD%8A%2B%8CWhe%5E%AF%CF%F5%3B%26%CE%CBh%5C%19%CE%CB%B0%F3%A4%095%A1%CAP%19*Ce%A8%0C%3BO*Ce%A8%0C%95%A12%3A%AD%8C%0A%82%7B%F0v%1F%2FD%A9%5B%9F%EE%EA%26%AF%03%CA%DF9%7B%19*Ce%A8%0C%95%A12T%86%CA%B8Ze%D8%CBP%19*Ce%A8%0C%95%D1ae%EC%F7%89I%E1%B4%D7M%D7P%8BjU%5C%BB%3E%F2%20%D8%CBP%19*Ce%A8%0C%95%A12T%C6%D5*%C3%5E%86%CAP%19*Ce%B4O%07%7B%F0W%7Bw%1C%7C%1A%8C%B3%3B%D1%EE%AA%5C%D6-%EBV%83%80%5E%D0%CA%10%5CU%2BD%E07YU%86%CAP%19*%E3%9A%95%91%D9%A0%C8%AD%5B%EDv%9E%82%FFKOee%E4%8FUe%A8%0C%95%A12T%C6%1F%A9%8C%C8%3D%5B%A5%15%FD%14%22r%E7B%9F%17l%F8%BF%ED%EAf%2B%7F%CF%ECe%D8%CBP%19*Ce%A8%0C%95%E1%93~%7B%19%F62T%86%CAP%19*Ce%A8%0C%E7%13%DA%CBP%19*Ce%A8%0CZf%8B%16-Z%B4h%D1R%19f%8B%16-Z%B4h%D1R%19%B4%CC%16-Z%B4h%D1R%19%B4%CC%16-Z%B4h%D1%A2%A52%CC%16-Z%B4h%D1%A2%A52h%99-Z%B4h%D1%A2%A52h%99-Z%B4h%D1%A2EKe%98-Z%B4h%D1%A2EKe%D02%5B%B4h%D1%A2EKe%D02%5B%B4h%D1%A2E%8B%96%CA0%5B%B4h%D1%A2E%8B%96%CA%A0e%B6h%D1%A2E%8B%96%CA%A0e%B6h%D1%A2E%8B%16-%95a%B6h%D1%A2E%8B%16-%95A%CBl%D1%A2E%8B%16-%95A%CBl%D1%A2E%8B%16-Z*%C3l%D1%A2E%8B%16-Z*%83%96%D9%A2E%8B%16-Z*%83%96%D9%A2E%8B%16-Z%B4T%86%D9%A2E%8B%16-Z%B4T%06-%B3E%8B%16-Z%B4T%06-%B3E%8B%16-Z%B4h%A9%0C%B3E%8B%16-Z%B4h%A9%0CZf%8B%16-Z%B4h%A9%0CZf%8B%16-Z%B4h%D1R%19f%8B%16-Z%B4h%D1R%19%B4%CC%16-Z%B4h%D1R%19%B4%CC%16-Z%B4h%D1%A2%A52%CC%16-Z%B4h%D1%A2%A52h%99-Z%B4h%D1%A2%A52h%99-Z%B4h%D1%A2EKe%98-Z%B4h%D1%A2EKe%D02%5B%B4h%D1%A2EKe%D02%5B%B4h%D1%A2E%8B%96%CA0%5B%B4h%D1%A2E%8B%96%CA%A0e%B6h%D1%A2E%8B%96%CA%A0e%B6h%D1%A2E%8B%16-%95a%B6h%D1%A2E%8B%16-%95A%CBl%D1%A2E%8B%16-%95A%CBl%D1%A2E%8B%16-Z*%C3l%D1%A2E%8B%16-Z*%83%96%D9%A2E%8B%16-Z*%83%96%D9%A2E%8B%16-Z%B4T%86%D9%A2E%8B%16-Z%B4T%06-%B3E%8B%16-Z%B4T%06-%B3E%8B%16-Z%B4h%A9%0C%B3E%8B%16-Z%B4h%A9%0CZf%8B%16-Z%B4h%A9%0CZf%8B%16-Z%B4h%D1R%19f%8B%16-Z%B4h%D1R%19%B4%CC%16-Z%B4h%D1R%19%B4%CC%16-Z%B4h%D1%A2%A52%CC%16-Z%B4h%D1%A2%A52h%99-Z%B4h%D1%A2%A52h%99-Z%B4h%D1%A2EKe%98-Z%B4h%D1%A2EKe%D02%5B%B4h%D1%A2EKe%D02%5B%B4h%D1%A2E%8B%96%CA0%5B%B4h%D1%A2E%8B%96%CA%A0e%B6h%D1%A2E%8B%96%CA%A0e%B6h%D1%A2E%8B%16-%95a%B6h%D1%A2E%8B%16-%95A%CBl%D1%A2E%8B%16-%95A%CBl%D1%A2E%8B%16-Z*%C3l%D1%A2E%8B%16-Z*%83%96%D9%A2E%8B%16-Z*%83%96%D9%A2E%8B%16-Z%B4T%86%D9%A2E%8B%16-Z%B4T%06-%B3E%8B%16-Z%B4%AE%A4%F5%25%C0%00%DE%BF%5C'%0F%DA%B8q%00%00%00%00IEND%AEB%60%82") repeat-y !important;

    border-left: 1px solid #BBBBBB !important;

    border-right: 1px solid #000000 !important;

    border-bottom: 1px dashed #BBBBBB !important;

}



.overflowRulerX > .firebugRulerV {

    left: 0 !important;

}



.overflowRulerY > .firebugRulerH {

    top: 0 !important;

}



/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

.fbProxyElement {

    position: fixed !important;

    pointer-events: auto !important;

}

</style></head>

  <body>

    <header>

      <!-- Fixed navbar shown after scroll -->
      <nav class="navbar navbar-default navbar-fixed-top navbar-style" id="menu" style="display: none;">
        <div class="container-fluid">
          <div class="navbar-header">
            
              <a href="#">
                <img class="logo-navbar" src="OccupationWise_files/logo.svg">
              </a>
       
          </div>
            <div id="navbar" class="navbar-collapse collapse navbar-right">
           
            
              <a class="btn sign-in" href="#" role="button">Sign In</a>
              <a class="btn sign-up" href="#" role="button">Sign Up</a>
            </div><!--/.nav-collapse -->
        </div>
      </nav>

          <div id="sign-in-modal" class="modal modal-class fade" role="dialog">
            <div class="modal-dialog">
            <!-- Modal content-->
              <div class="modal-content">
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Sign in to your account</h4>
                  </div>
                  <div class="modal-body">
				  <div id="message_login"></div>
                    <form method="post">
                      <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                        <label for="username">Enter Email</label>
                        <input placeholder="Enter Email" type="text" id="mail1" name="email" class="form-control">
                      </div>
                      
                      <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                        <label for="password">Enter password</label>
                        <input placeholder="Enter Password" type="password" id="pass1" name="password" class="form-control">
                      </div>
                    </form>
                  </div>
                  <div class="modal-footer">
                    <input type="submit" class="btn btn-default hero-button" id='submit1' name="submit" value ="sign In"/>
                  </div>
              </div>
            </div>
          </div>
          <div id="sign-up-modal" class="modal modal-class fade" role="dialog">
              <div class="modal-dialog">
              <!-- Modal content-->
              <div class="modal-content">
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Sign in to your account</h4>
                  </div>
                  <div class="modal-body">
                    <form method="post"  action="">
					<div class="col-md-12 col-lg-12 col-sm-12 col-xs-12" id="message"  ></div>
                      <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                        <label for="username">Enter Firstname</label>
                        <input placeholder="Enter Firstname" type="text"  id="firstname"  name="firstname" class="form-control">
                      </div>
                      
                      <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                        <label for="lastname">Enter Lastname</label>
                        <input placeholder="Enter Lastname" type="text" id="lastname" name="lastname" class="form-control">
                      </div>
                      <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                        <label for="email">Enter Email</label>
                        <input placeholder="Enter Email" type="email"  id ="email" name="email" class="form-control">
                      </div>
                      <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                        <label for="password">Enter Password</label>
                        <input placeholder="Enter Password" type="password" id='password' name="password" class="form-control">
                      </div>

                      <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                        <label for="repassword">Confirm Password</label>
                        <input placeholder="Confirm Password" type="password" id ="repassword" name="repassword" class="form-control">
						
                      </div>
					  
					  <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                        <p class="select-option">Please share with us who you are (check all that apply)</p>
						<div class="checkbox">
						<label>
						  <input type="checkbox" name="student" value="student" id="student"> Student st
						</label>
						<label>
						  <input type="checkbox"name="check[]" value="parent" id="parent"> Parent
						</label>
						<label>
						  <input type="checkbox" name="check[]"value="bussiness sponser" id="business"> Business sponser					
						</label>
						<label>
						  <input type="checkbox" name="check[]" value="working professionals" id="working"> Working professionals (maybe potential mentor)
						</label>
						
					  </div>
						
                      </div>
					  
                    </form>
                  </div>
                  <div class="modal-footer">
                    <input type="submit" class="btn btn-default hero-button" id='submit' name="submit" value ="sign up"/>
                  </div>
                </div>
              </div>
          </div>


      <div class="hero-home-image">

        <div class="inner">

          <div class="container-fluid">

            <div class="navbar-right padding-right">
            	<a href="about.html" class="btn sign-in">About</a>
              <a class="btn sign-in" href="#" role="button" data-toggle="modal" data-target="#sign-in-modal">Sign In</a>
              <a class="btn sign-up" href="#" role="button" data-toggle="modal" data-target="#sign-up-modal">Sign Up</a>
            </div>

          </div>

            <!-- Main component for a primary marketing message or call to action -->
            <div class="hero-container">

              <div class="logo" id="logo">
                  <img src="OccupationWise_files/logo.svg">
              </div>
              <div class="hero-text">
              Love what you do. We'll help you get there.

              </div>

            </div> <!-- /container -->

            <div class="container hero-buttons-container">

              <h3>First, tell us a bit about yourself.</h3>
              <p> I am a:</p>

              <div class="col-lg-12 col-sm-12">
			  <div id="survey_model_Parent" class="modal modal-class fade" role="dialog">
            <div class="modal-dialog">
            <!-- Modal content-->
              <div class="modal-content">
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Parent Survey</h4>
                  </div>
                  <div class="modal-body">
				  <iframe  src="https://www.surveymonkey.com/r/9Y3RHVJ" ></iframe> 
                 
                  </div>
                 
              </div>
            </div>
 </div>
 <div id="survey_model" class="modal modal-class fade" role="dialog">
            <div class="modal-dialog">
            <!-- Modal content-->
              <div class="modal-content">
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Student Survey</h4>
                  </div>
                  <div class="modal-body">
				 
                   <iframe  src="https://www.surveymonkey.com/r/9YFLM8H" ></iframe> 
                 
                  </div>
                 
              </div>
            </div>
 </div>
 <div id="survey_model_Mentor" class="modal modal-class fade" role="dialog">
            <div class="modal-dialog">
            <!-- Modal content-->
              <div class="modal-content">
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Mentor Survey</h4>
                  </div>
                  <div class="modal-body">
				 
				 <iframe  src="https://www.surveymonkey.com/r/9Y3HGM7" ></iframe> 
                 
                  </div>
                 
              </div>
            </div>
 </div>
                  
    <div id="survey_model_Sponsor" class="modal modal-class fade" role="dialog">
            <div class="modal-dialog">
            <!-- Modal content-->
              <div class="modal-content">
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Sponsor Survey</h4>
                  </div>
                  <div class="modal-body">
			<iframe  src="https://www.surveymonkey.com/r/6G339TK" ></iframe> 	 
               
                  </div>
                 
              </div>
            </div>
 </div>
                  
                


<a class="btn hero-button" href="#" role="button" data-toggle="modal" data-target="#survey_model_Parent">Parent</a>
<a class="btn hero-button" href="#" role="button" data-toggle="modal" data-target="#survey_model">Student</a>
<a class="btn hero-button" href="#" role="button" data-toggle="modal" data-target="#survey_model_Mentor">Mentor</a>
<a class="btn hero-button" href="#" role="button" data-toggle="modal" data-target="#survey_model_Sponsor">Sponsor</a>
<!--<a class="btn hero-button  std"  href=https://www.surveymonkey.com/mp/customer-satisfaction-surveys/>Student</a <a class="btn hero-button" href="#" role="button">Parent</a>   <a class="btn hero-button" href="#" role="button">Student</a><a class="btn hero-button" href="#" role="button">Mentor</a><a class="btn hero-button" href="#" role="button">Sponsor</a>-->
                  
                  

            </div>

        </div>

      </div>

    </div></header>

    <div class="banner-goals">

      <div class="container">

        <div class="row match">
          <div>
            <img class="img-goals" src="OccupationWise_files/match.svg">
          </div>
		  
          <div class="headline">
            <span>OccupationWise matches you with your career goals.</span>
          </div>
          <div class="subheadline">
            We are on a mission to find out exactly how many unique 
career opportunities exist so we can help you make a wise decision on 
which career suits you.
          </div>

        </div>


      </div>

      <div class="container">

        <div class="row section-title">
          <span>With our services you can:</span>
        </div>

        <div class="row row-services">
          
          <div class="col-lg-4 col-md-4 col-sm-4" id="panels">
            <div class="panel-services">
              <img class="img-services" src="OccupationWise_files/services-mentor.svg">
              <div class="text-services">
                <h3>Find a Mentor</h3>
                <p>Learn directly from professionals about what daily 
life in their field looks like and how they got there. Network with 
professionals and peers.</p>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-4 col-sm-4" id="panels">
            <div class="panel-services">
              <img class="img-services" src="OccupationWise_files/services-career.svg">
              <div class="text-services">
                <h3>Train For a Career</h3>
                <p>Once you’ve found a career you’re interested in, explore options on schooling or training to set you on the path to success.</p>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-4 col-sm-4" id="panels">
            <div class="panel-services">
              <img class="img-services" src="OccupationWise_files/services-hired2x.png">
              <div class="text-services">
                <h3>Get Hired</h3>
                <p>Put what you learn into practice by locating an internship that is the perfect match for you by using our Live Résumé.</p>
              </div>
            </div>
          </div>

        </div>

        <div class="row">
          <div class="col-lg-12 col-md-12 col-sm-12">

            <a class="btn hero-button btn-create-account" href="#" role="button" data-toggle="modal" data-target="#sign-up-modal">Create an Account</a>

          </div>
        </div>
      </div>

    </div>

    <div class="banner-fields">

      <div class="container">

        <div class="row section-title">
          <span>Learn more about the many possible fields below</span>
        </div>

        <div class="row row-fields">

          <div class="col-lg-4 col-md-4 col-sm-4" id="panel-grid">

            <div class="panel-fields">
              <div class="ribbon-overlay">
                <img src="OccupationWise_files/ribbon.svg">
              </div>
              <img class="img-fields" src="OccupationWise_files/creative.svg">
              <h3>Creative</h3>
            </div>
          </div>

          <div class="col-lg-4 col-md-4 col-sm-4" id="panel-grid">
            <div class="panel-fields">
              <div class="ribbon-overlay">
                <img src="OccupationWise_files/ribbon.svg">
              </div>
              <img class="img-fields" src="OccupationWise_files/technology.svg">
              <h3>Technology</h3>
            </div>
          </div>

          <div class="col-lg-4 col-md-4 col-sm-4" id="panel-grid">
            <div class="panel-fields">
              <div class="ribbon-overlay">
                <img src="OccupationWise_files/ribbon.svg">
              </div>
              <img class="img-fields" src="OccupationWise_files/accounting.svg">
              <h3>Accounting</h3>
            </div>
          </div>

        </div>

        <div class="row row-fields">
          
          <div class="col-lg-4 col-md-4 col-sm-4" id="panel-grid">
            <div class="panel-fields">
              <img class="img-fields" src="OccupationWise_files/finance.svg">
              <h3>Finance</h3>
            </div>
          </div>

          <div class="col-lg-4 col-md-4 col-sm-4" id="panel-grid">
            <div class="panel-fields">
              <div class="ribbon-overlay">
                <img src="OccupationWise_files/ribbon.svg">
              </div>
              <img class="img-fields" src="OccupationWise_files/healthcare.svg">
              <h3>Health Care</h3>
            </div>
          </div>

          <div class="col-lg-4 col-md-4 col-sm-4" id="panel-grid">
            <div class="panel-fields">
              <div class="ribbon-overlay">
                <img src="OccupationWise_files/ribbon.svg">
              </div>
              <img class="img-fields" src="OccupationWise_files/engineering.svg">
              <h3>Engineering</h3>
            </div>
          </div>

        </div>

        <div class="row row-fields">
          
          <div class="col-lg-4 col-md-4 col-sm-4" id="panel-grid">
            <div class="panel-fields">
              <div class="ribbon-overlay">
                <img src="OccupationWise_files/ribbon.svg">
              </div>
              <img class="img-fields" src="OccupationWise_files/sciencebiotech.svg">
              <h3>Science &amp; Biotech</h3>
            </div>
          </div>

          <div class="col-lg-4 col-md-4 col-sm-4" id="panel-grid">
            <div class="panel-fields">
              <div class="ribbon-overlay">
                <img src="OccupationWise_files/ribbon.svg">
              </div>
              <img class="img-fields" src="OccupationWise_files/nonprofit.svg">
              <h3>Nonprofit</h3>
            </div>
          </div>

          <div class="col-lg-4 col-md-4 col-sm-4" id="panel-grid">
            <div class="panel-fields">
              <div class="ribbon-overlay">
                <img src="OccupationWise_files/ribbon.svg">
              </div>
              <img class="img-fields" src="OccupationWise_files/legal.svg">
              <h3>Legal</h3>
            </div>
          </div>

        </div>

        <div class="row">
          <div class="col-lg-12 col-md-12 col-sm-12">

            <a class="btn hero-button btn-create-account" href="#" role="button">Create an Account</a>

          </div>
        </div>
      </div>

    </div>
    <div class="newsletter">
      <div class="container">

        <div class="row">
          <div class="col-lg-12 newsletter-text">
            <h3>We're just getting started!</h3>
            <span>Sign up to get updates and plenty of career inspiration.</span>
          </div>
          <form method="post" action="keep_update.php">
            <div class="form-group">
              <input class="form-control"  name="fname" placeholder="Full name" type="text">
              <input class="form-control" name="email" placeholder="Email address" type="email">
	<input type="submit" class="btn btn-default hero-button"  name="submit2" value ="update"/>
			  
            </div>
          </form>
          

        </div>

      </div>
    </div>

    <footer>
    
      <div class="footer-container">

          <a href="#">
            <img class="logo-footer" src="OccupationWise_files/logo.svg">
          </a>

        <div class="footer-social">
          <a href="#">
            <img class="footer-social-icons" src="OccupationWise_files/ico_facebook.svg" id="facebook">
          </a>
          <a href="#">
            <img class="footer-social-icons" src="OccupationWise_files/ico_twitter.svg" id="twitter">
          </a>
          <a href="#">
            <img class="footer-social-icons" src="OccupationWise_files/ico_linkedin.svg" id="linkedin">
          </a>
          <a href="#">
            <img class="footer-social-icons" src="OccupationWise_files/ico_googleplus.svg" id="google">
          </a>
          <a href="#">
            <img class="footer-social-icons" src="OccupationWise_files/ico_rss.svg" id="rss">
          </a>
        </div>
        <span class="footer-copyright">Copyright © <script type="text/javascript"> document.write(new Date().getFullYear());</script>2016 OccupationWise</span>
      </div>


    </footer>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="OccupationWise_files/jquery.js"></script>
    <script>window.jQuery || document.write('<script src="js/jquery.min.js"><\/script>')</script>
    <script src="OccupationWise_files/bootstrap.js"></script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="OccupationWise_files/ie10-viewport-bug-workaround.js"></script>

    <script type="text/javascript">
    (function($) {          
        $(document).ready(function(){                    
            $(window).scroll(function(){                          
                if ($(this).scrollTop() > 300) {
                    $('#menu').fadeIn(500);
                } else {
                    $('#menu').fadeOut(500);
                }
            });
        });
    })(jQuery);
	
	
	$(document).ready(function(){
$("#submit").click(function(){
	//alert("hii");
var firstname = $("#firstname").val();
var lastname = $("#lastname").val();
var email = $("#email").val();
var password = $("#password").val();
var repassword = $("#repassword").val();

var student=$("#student:checked").val();
var parent= $("#parent:checked").val();
var business=$("#business:checked").val();
var 
=$("#working:checked").val();

  
      

 
var dataString = 'firstname='+ firstname + '&lastname='+ lastname + '&email='+ email + '&password='+ password + '&student=' + student + '&parent=' + parent + '&business=' + business + '&working=' + working;
alert(dataString);
 
	
		

if(password == repassword)
{
if(firstname==''||lastname==''||email==''||password=='')
{
alert("Please Fill All Fields");
}

else
{
// AJAX Code To Submit Form.
$.ajax({
type: "POST",
url: "register.php",
data: dataString,
cache: false,
success: function(result){

$('#message').html('');

if(result == true)
{
	$('#message').html('<div class="alert alert-danger"><strong>Danger!</strong> Indicates a dangerous or potentially negative action.</div>');
}
else
{
	//$('#message').html('<div class="alert alert-success"><strong>Success!</strong> Indicates a successful or positive action.</div>');
	window.location.href="welcome.php";
}	

}
});
}
return false;
}
else
{
	alert('Password not match');
}	
});
});

   
	
	
	$(document).ready(function(){
$("#submit1").click(function(){
	//alert("hii");
	

var mail1 = $("#mail1").val();
var pass1 = $("#pass1").val();

//var date=$().val();


// Returns successful data submission message when the entered information is stored in database.
var dataString ='mail1='+ mail1 + '&pass1='+ pass1;


if(mail1==''||pass1=='')
{
alert("Please Fill All Fields");
}
else
{
// AJAX Code To Submit Form.
$.ajax({
type: "POST",
url: "login.php",
data: dataString,
cache: false,
success: function(result){
alert(result);
$('#message_login').html('');

if(result == true)
{
	$('#message_login').html('<div class="alert alert-danger"><strong>Danger!</strong> Indicates a dangerous or potentially negative action.</div>');
}
else
{
	window.location.href="sign.php";
	//$('#message_login').html('<div class="alert alert-success"><strong>Success!</strong> Indicates a successful or positive action.</div>');	
}	

}
});
}


});
});
	
	</script>
    

    <div id="window-resizer-tooltip" style="display: none;"><a href="#" title="Edit settings"></a><span class="tooltipTitle">Window size: </span><span class="tooltipWidth" id="winWidth">1352</span> x <span class="tooltipHeight" id="winHeight">716</span><br><span class="tooltipTitle">Viewport size: </span><span class="tooltipWidth" id="vpWidth">871</span> x <span class="tooltipHeight" id="vpHeight">642</span></div>
  
  


<canvas id="colorPickerFrameCanvas" height="1" width="1"></canvas><canvas id="colorPickerFrameCanvas" height="1" width="1"></canvas><canvas id="colorPickerFrameCanvas" height="1" width="1"></canvas><canvas id="colorPickerFrameCanvas" height="1" width="1"></canvas></body></html>