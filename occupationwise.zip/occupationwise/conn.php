<?php 
$con=mysqli_connect("localhost","occupat8_occu","U[xE(I&vTcMT");
if(!$con)
 {
 	die("error".mysqli_error());
 	}
 	else 
 	{
 		mysqli_select_db($con,"occupat8_occupationWise");
 		//echo "Connection successful";
 		}
 		?>
