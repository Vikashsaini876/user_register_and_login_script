-- phpMyAdmin SQL Dump
-- version 4.0.10.18
-- https://www.phpmyadmin.net
--
-- Host: localhost:3306
-- Generation Time: Apr 28, 2017 at 05:34 AM
-- Server version: 5.6.28-76.1-log
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `occupat8_occupationWise`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin_user`
--

CREATE TABLE IF NOT EXISTS `tbl_admin_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone_no` int(11) NOT NULL,
  `password` varchar(100) NOT NULL,
  `last_update` datetime NOT NULL,
  `last_login` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `tbl_admin_user`
--

INSERT INTO `tbl_admin_user` (`id`, `fname`, `lname`, `email`, `phone_no`, `password`, `last_update`, `last_login`) VALUES
(1, 'ankit', 'xcvx', 'xcvx', 787899, '1234', '2016-12-22 00:00:00', '2016-12-29 00:00:00'),
(2, 'assd', 'dfs', '', 0, '12345', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(3, 'assd', 'dfs', 'admin@fg', 0, '12345', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(4, 'Ankit', 'Mishra', 'ankit@gmail.com', 123456, '123456', '2016-12-21 00:00:00', '2016-12-09 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_register_user`
--

CREATE TABLE IF NOT EXISTS `tbl_register_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `registration_type` varchar(100) NOT NULL,
  `signup_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `login_status` enum('0','1') NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=43 ;

--
-- Dumping data for table `tbl_register_user`
--

INSERT INTO `tbl_register_user` (`id`, `fname`, `lname`, `email`, `password`, `registration_type`, `signup_date`, `login_status`) VALUES
(1, 'ankit', 'hgdfhg', 'admin@gmail.coim', '81dc9bdb52d04dc20036dbd8313ed055', '', '2016-12-09 12:01:16', '1'),
(2, 'adasd', 'asdasd', 'admin@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', '', '2016-12-09 12:02:23', '1'),
(3, 'test', 'test', 'admin@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', '', '2016-12-09 12:04:15', '1'),
(4, 'ann', 'hgfth', 'admin', '81dc9bdb52d04dc20036dbd8313ed055', '', '2016-12-09 12:07:47', '1'),
(5, 'ankit', 'mishra', 'ankit@gmail.com', '1234', '1', '2016-12-20 18:30:00', '1'),
(6, 'ankit', 'mishra', 'ankit@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', '', '2016-12-09 12:50:12', '1'),
(14, 'anuarg ', 'kasyap', 'admin@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', '', '2016-12-10 05:05:00', '1'),
(15, 'nishan', 'singh', 'nishan@gmail.com', '4fd4021def2343e78737f699a8b16755', '', '2016-12-10 06:15:44', '1'),
(16, 'prabjeet', 'grewal', 'prabjeet@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', '', '2016-12-10 07:51:41', '1'),
(18, 'ankit', 'fd', 'admin', '81dc9bdb52d04dc20036dbd8313ed055', '', '2016-12-10 08:13:13', '1'),
(19, 'ankit', 'fd', 'admin', '81dc9bdb52d04dc20036dbd8313ed055', '', '2016-12-10 08:13:14', '1'),
(20, 'ankit', 'kumar', 'admingmail.com', '202cb962ac59075b964b07152d234b70', '', '2016-12-10 10:05:24', '1'),
(21, 'amit', 'kumar', 'amit@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', '', '2016-12-10 10:12:01', '1'),
(22, 'amit', 'kumar', 'amit@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', '', '2016-12-10 10:12:07', '1'),
(23, 'anurag ', 'kumar', 'amit@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', '', '2016-12-10 10:14:30', '1'),
(24, 'anurag ', 'kumar', 'amit@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', '', '2016-12-10 10:14:31', '1'),
(25, 'anurag ', 'kumar', 'amit@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', '', '2016-12-10 10:14:31', '1'),
(26, 'anurag ', 'kumar', 'amit@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', '', '2016-12-10 10:14:31', '1'),
(32, 'ashok', 'singh', 'abc@gmail.com', '80f90c81fe718dc1a3e269a1cf00176a', '', '2016-12-10 11:32:01', '1'),
(34, 'vbnv', 'vbn v', 'admin@gaj', '827ccb0eea8a706c4c34a16891f84e7b', '', '2016-12-10 11:37:32', '1'),
(37, 'puja', 'shrama', 'adddd@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', '', '2016-12-12 12:51:43', '1'),
(38, 'ankit', 'mishra', 'ankit@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', 'student,parent,bussiness sponser,working professionals', '2016-12-15 09:43:23', '1'),
(39, 'anurag ', 'kasyap', 'A@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', 'student,parent,bussiness sponser', '2016-12-15 09:44:29', '1'),
(40, '', '', '', 'd41d8cd98f00b204e9800998ecf8427e', ',,,', '2017-03-19 10:23:20', '1'),
(41, '', '', '', 'd41d8cd98f00b204e9800998ecf8427e', ',,,', '2017-04-28 08:31:19', '1'),
(42, '', '', '', 'd41d8cd98f00b204e9800998ecf8427e', ',,,', '2017-04-28 08:31:46', '1');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_subscriber`
--

CREATE TABLE IF NOT EXISTS `tbl_subscriber` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `tbl_subscriber`
--

INSERT INTO `tbl_subscriber` (`id`, `name`, `email`, `status`) VALUES
(1, 'Ankit Mishra', 'ankit@gmail.com', '1'),
(2, 'Mishra Ankit Kumar', 'ankit@gmail.com', '1'),
(3, 'Mishra Ankit Kumar', 'ankit@gmail.com', '1'),
(4, '', '', '1'),
(5, '', '', '1'),
(6, 'Mishra Ankit Kumar', 'ankit@gmail.com', '1'),
(7, 'ankit', 'qwertyankit112@gmail.com', '1'),
(8, 'Ashish', 'hrashuhbo@gmail.com', '1'),
(9, 'Monique Keshishian', 'Monique.Keshishian@gmail.com', '1'),
(10, 'Mishra Ankit kumar', 'ankit.codemantar@gmail.com', '1'),
(11, 'test', 'test@gmail.com', '1');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
