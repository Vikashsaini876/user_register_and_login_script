<?php
	
$conn = mysqli_connect('localhost', 'root', '', 'php_data');
 
if(isset($_POST['submit_row']))
{
 
 $name=$_POST['name'];
 $age=$_POST['age'];
 $job=$_POST['job'];
 for($i=0;$i<count($name);$i++)
 {
  if($name[$i]!="" && $age[$i]!="" && $job[$i]!="")
  {
   $insert = mysqli_query($conn,"insert into employee_table values('','$name[$i]','$age[$i]','$job[$i]')");
   if($insert)
   {
      echo 'Data Inserted Successfully.<br>';   
   }
  }
 }
}
?>