<?php 
/* Template Name: Broker Page Details 
*/ 
get_header();
$dealidd= $_GET['id'];
global $wpdb;
$new_result = $wpdb->get_results("SELECT * FROM deals where id = '".$dealidd."'");
$primIdd = $new_result[0]->id;
$estateId = $new_result[0]->mainEstateId;

$cont_id = $new_result[0]->mainBrokerContactId;


$estate_img_result = $wpdb->get_results("SELECT * FROM imagesInEstates where estateId = '".$estateId."' and category !='ENUMS_IMAGES_IN_ESTATES_CATEGORY_FLOOR_PLAN' and category !='ENUMS_IMAGES_IN_ESTATES_CATEGORY_MAP' and category !=''");

$estate_img_result_plan = $wpdb->get_results("SELECT * FROM imagesInEstates where estateId = '".$estateId."' and category !='ENUMS_IMAGES_IN_ESTATES_CATEGORY_INTERNAL' and category !='ENUMS_IMAGES_IN_ESTATES_CATEGORY_MAP' and category !='ENUMS_IMAGES_IN_ESTATES_CATEGORY_EXTERIOR' ");
//echo "<pre>";
//print_r($estate_img_result_plan);
//ENUMS_IMAGES_IN_ESTATES_CATEGORY_MAP
//echo "<pre>";
//print_r($estate__result);exit;


$estate_result1 = $wpdb->get_results("SELECT * FROM estates where estates.id = '".$estateId."'");
//echo "<pre>";
//print_r($estate_result1);
$brocker_data = $wpdb->get_results("select * from contacts where contacts.id ='".$cont_id."'");
//echo "<pre>";
//print_r($brocker_data);

$building_details = $wpdb->get_results("select * from buildings where buildings.estateId ='".$estateId."'");
$mortages_details = $wpdb->get_results("select * from mortgages where mortgages.estateId ='".$estateId."'");
//echo "<pre>";
//print_r($mortages_details);
//echo "<pre>";
//print_r($building_details);
//echo "<pre>";
//print_r($brocker_data);
//$building_details = $wpdb->get_results("select * from buildings where buildings.estateId ='".$estateId."'");

?>
<section class="banner-section">  
    <div class="homepage-slider">
        <div class="flexslider">
            <ul class="slides">
			<?php 
			foreach($estate_img_result as $rowestate_result)
				{
					$estate_images_result = $wpdb->get_results("SELECT * FROM files where id = '".$rowestate_result->fileId."'");
					foreach($estate_images_result as $rowIMAGES)
					{
						echo "<li data-thumb='".$rowIMAGES->viewURI."'><img src='".$rowIMAGES->viewURI."' border='0'  /></li> ";
					}
				}
				?>
                
            </ul>
        </div>
    </div>
</section>

<section class="listing-detail-section">
    <div class="heading-info-box">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-9 col-md-8">
                    <h1>Lysekil Tegen 1:16 </h1>
                    <div class="row">
                        <div class="col-xs-12 col-sm-6">
                            <h5>Harry Hansson</h5>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Error, eum! Suscipit aliquid similique, vitae reiciendis ipsa error, deserunt nam eligendi cupiditate quam repellat obcaecati, fugiat soluta blanditiis tempore minus, dolores.</p>
                            <p><span><i class="fa fa-phone"></i></span>+46705903972</p>
                            <p><span><i class="fa fa-phone"></i></span></p>
                            <p><span><i class="fa fa-envelope"></i></span>barbro@nesje.se</p>
                        </div>
                        <div class="col-xs-12 col-sm-6">
                            <h5>Harry Hansson</h5>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Error, eum! Suscipit aliquid similique, vitae reiciendis ipsa error, deserunt nam eligendi cupiditate quam repellat obcaecati, fugiat soluta blanditiis tempore minus, dolores.</p>
                            <p><span><i class="fa fa-phone"></i></span>+46705903972</p>
                            <p><span><i class="fa fa-phone"></i></span></p>
                            <p><span><i class="fa fa-envelope"></i></span>barbro@nesje.se</p>
                        </div>
                    </div> 
                </div>
            </div>
        </div>
    </div>
</section>
<?php
//echo "SELECT * FROM filesInDeals as s JOIN files as c where s.fileId=c.id and s.dealId= '".$primIdd."' and c.viewURI !=''";

$photo_result = $wpdb->get_results("SELECT * FROM filesInDeals as s JOIN files as c where s.fileId=c.id and s.dealId= '".$primIdd."' and c.viewURI !=''");
//echo "<pre>";
//print_r($photo_result);

?>


<?php 
//$estate_result = $wpdb->get_results("SELECT * FROM estates JOIN files where estates.id = '".$estateId."' and estates.mainImageFileId = files.id ");

//echo "SELECT * FROM rooms JOIN imagesInRooms where rooms.estateId = '".$estateId."' and rooms.id = imagesInRooms.roomId";

$room_result = $wpdb->get_results("SELECT * FROM rooms JOIN imagesInRooms where rooms.estateId = '".$estateId."' and rooms.id = imagesInRooms.roomId");

//echo "<pre>";

//print_r($room_result);

?>
<div id="homepage-listing-section">
    <section class="listing-property-section">
        <div class="filter-menu-section">
            <div class="row">
                <div class="container">
                    <div class="col-md-12">
                        <nav class="filter-menu">
                            <ul>
                                <li class="active" data-toggle="tab" data-target="#Information">
                                    <a href="#">Information</a>
                                </li>
                                <li data-toggle="tab" data-target="#Object-Facts"><a href="#">Object Facts</a>
                                </li>
                                <li data-toggle="tab" data-target="#Photos"><a href="#">Photos</a>
                                </li>
                                <li data-toggle="tab" data-target="#Plan"><a href="#">Plan</a>
                                </li>
                                <li data-toggle="tab" data-target="#Map"><a href="#">Map</a>
                                </li>
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
        <div class="tab-content category-grid">        
            <div class="clearfix tab-pane active" id="Information">
                <div class="listing-image-gallery">
                    <div class="container">
                        <div class="col-sm-9">
						<!--<style>.hide-descpt{display:block}</style>-->
                            <div class="broker-tabs">
								<?php if($estate_result1[0]->description!=''){?>
                                <h3>Description</h3>
                                <p><?php echo $estate_result1[0]->description; ?></p>
								<?php }?>
                            </div>
                            <div class="broker-tabs">
								<?php if($estate_result1[0]->roomsDescription!=''){?>
                                <h3>Room description</h3>
                                <p><?php echo $estate_result1[0]->roomsDescription; ?></p>
								<?php }?>
                            </div>
                            <div class="broker-tabs">
								<?php if($estate_result1[0]->plotDescription!=''){?>
                                <h3>Other</h3>
								
                                <p><?php echo $estate_result[0]->plotDescription; ?></p>
								<?php }?>
                            </div>
                        </div>
						<!--<div class="col-sm-9">
						<!--<style>.hide-descpt{display:none}</style>-->
							<?php //$abcdd= '<div class="hide-descpt">'?>
                            <!--<div class="broker-tabs">
								<?php //if($estate_result1[0]->description==''){echo $abcdd;}?>
                                <h3>Description</h3>
                                <p><?php //echo $estate_result1[0]->description; ?></p>
                            </div>
							<?php //echo '</div>'?>
							<?php //$abcdd= '<div class="hide-descpt">'?>
                            <div class="broker-tabs">
                                <h3>Room description</h3>
                                <p><?php //echo $estate_result1[0]->roomsDescription; ?></p>
                            </div>
							<?php //echo '</div>'?>
							<?php //$abcdde= '<div class="hide-descpt">'?>
                            <div class="broker-tabs">
							<?php //if($estate_result1[0]->plotDescription==''){echo $abcdd;}?>
                                <h3>Other</h3>
                                <p><?php //echo $estate_result[0]->plotDescription; ?></p>
                            </div>
							<?php //echo '</div>'?>
                        </div>-->
                        <div class="col-sm-3">
                            <div class="broker-form">
                                <h3>Interested?</h3>
								<?php echo do_shortcode('[contact-form-7 id="50" title="Brokers Detail Page Contact Form"]');?>
                                <!--<form>
                                    <div class="form-group">
                                        <input type="text" placeholder="First Name" class="form-control">
                                    </div>
                                    <div class="form-group">
                                        <input type="text" placeholder="Last Name" class="form-control">
                                    </div>
                                    <div class="form-group">
                                        <input type="text" placeholder="E-post" class="form-control">
                                    </div>
                                    <div class="form-group">
                                        <input type="text" placeholder="Telephone" class="form-control">
                                    </div>
                                    <div class="form-group">
                                        <input type="submit" class="broker-send-btn">
                                    </div>
                                </form>-->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="clearfix tab-pane" id="Object-Facts">
                <div class="listing-image-gallery">
                    <div class="container">
                        <div class="col-sm-9">
                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="broker-tabs">
									   <h3>General Information</h3>
                                        <div class="field-names">
                                            <div class="row">
												<div class="col-xs-12">
                                                    <div class="row">
                                                        <div class="col-xs-4 col-sm-3">
                                                            <h5>Price:</h5>
                                                        </div>
                                                        <div class="col-xs-8 col-sm-9">
                                                            <p><?php echo $new_result[0]->startingPrice; ?></p>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-xs-12">
                                                    <div class="row">
                                                        <div class="col-xs-4 col-sm-3">
                                                            <h5>Room's</h5>
                                                        </div>
                                                        <div class="col-xs-8 col-sm-9">
                                                            <p><?php echo $estate_result1[0]->numberOfRoom."(Including ".$estate_result1[0]->numberOfBedrooms." Bedroom's)"; ?></p>
                                                        </div>
                                                    </div>
                                                </div>
												  <div class="col-xs-12">
                                                    <div class="row">
														<?php if($estate_result1[0]->totalArea!=''){?>
                                                        <div class="col-xs-4 col-sm-3">
                                                            <h5>Plot Size:</h5>
                                                        </div>
                                                        <div class="col-xs-8 col-sm-9">
                                                            <p><?php echo $estate_result1[0]->totalArea; ?></p>
                                                        </div>
                                                        <?php }?>
                                                    </div>
                                                </div>
                                                <div class="col-xs-12">
                                                    <div class="row">
														<?php if($estate_result1[0]->plotDescription!=''){?>
                                                        <div class="col-xs-4 col-sm-3">
                                                            <h5>Plot Description:</h5>
                                                        </div>
                                                        <div class="col-xs-8 col-sm-9">
                                                            <p><?php echo $estate_result1[0]->plotDescription; ?></p>
                                                        </div>
                                                        <?php }?>
                                                    </div>
                                                </div> 
												  <div class="col-xs-12">
                                                    <div class="row">
                                                        <div class="col-xs-4 col-sm-3">
                                                            <h5>Living Area:</h5>
                                                        </div>
                                                        <div class="col-xs-8 col-sm-9">
                                                            <p><?php echo $estate_result1[0]->totalLivingArea; ?></p>
                                                        </div>
                                                    </div>
                                                </div>   
                                                 <div class="col-xs-12">
                                                    <div class="row">
                                                        <div class="col-xs-4 col-sm-3">
                                                            <h5>Biarea:</h5>
                                                        </div>
                                                        <div class="col-xs-8 col-sm-9">
                                                            <p><?php echo $estate_result1[0]->otherLivingArea; ?></p>
                                                        </div>
                                                    </div>
                                                </div>    
                                                <div class="col-xs-12">
                                                    <div class="row">
                                                        <div class="col-xs-4 col-sm-3">
                                                            <h5>Assess Building:</h5>
                                                        </div>
                                                        <div class="col-xs-8 col-sm-9">
                                                            <p><?php echo $estate_result1[0]->assessValueBuilding; ?></p>
                                                        </div>
                                                    </div>
                                                </div>
												 <div class="col-xs-12">
                                                    <div class="row">
                                                        <div class="col-xs-4 col-sm-3">
                                                            <h5>Assess Land:</h5>
                                                        </div>
                                                        <div class="col-xs-8 col-sm-9">
                                                            <p><?php echo $estate_result1[0]->assessValueLand; ?></p>
                                                        </div>
                                                    </div>
                                                </div>
                                        		<div class="col-xs-12">
                                                    <div class="row">
                                                        <div class="col-xs-4 col-sm-3">
                                                            <h5>Total Assessed:</h5>
                                                        </div>
                                                        <div class="col-xs-8 col-sm-9">
                                                            <p><?php echo $estate_result1[0]->assessValueTotal; ?></p>
                                                        </div>
                                                    </div>
                                                </div>
												  <div class="col-xs-12">
                                                    <div class="row">
                                                        <div class="col-xs-4 col-sm-3">
                                                            <h5>Tenent:</h5>
                                                        </div>
                                                        <div class="col-xs-8 col-sm-9">
                                                            <p><?php echo $estate_result1[0]->housingAssociationName; ?></p>
                                                        </div>
                                                    </div>
                                                </div>
                                        		<div class="col-xs-12">
                                                    <div class="row">
                                                        <div class="col-xs-4 col-sm-3">
                                                            <h5>Apartment Number:</h5>
                                                        </div>
                                                        <div class="col-xs-8 col-sm-9">
                                                            <p><?php echo $estate_result1[0]->apartmentNumber; ?></p>
                                                        </div>
                                                    </div>
                                                </div>
												  <div class="col-xs-12">
                                                    <div class="row">
                                                        <div class="col-xs-4 col-sm-3">
                                                            <h5>Profile Shares:</h5>
                                                        </div>
                                                        <div class="col-xs-8 col-sm-9">
                                                            <p><?php echo $estate_result1[0]->shareInCondo; ?></p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                             	<div class="col-sm-12">
                                    <div class="broker-tabs">
									   <h3>Building</h3>
                                        <div class="field-names">
                                            <div class="row">
												 <div class="col-xs-12">
                                                    <div class="row">
                                                        <div class="col-xs-4 col-sm-3">
                                                            <h5>Built Year:</h5>
                                                        </div>
                                                        <div class="col-xs-8 col-sm-9">
                                                            <p><?php echo $estate_result1[0]->buildYear; ?></p>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-xs-12">
                                                    <div class="row">
                                                        <div class="col-xs-4 col-sm-3">
                                                            <h5>Ventilation Type:</h5>
                                                        </div>
                                                        <div class="col-xs-8 col-sm-9">
                                                            <p><?php echo $estate_result1[0]->ventilationType; ?></p>
                                                        </div>
                                                    </div>
                                                </div>
												  <div class="col-xs-12">
                                                    <div class="row">
                                                        <div class="col-xs-4 col-sm-3">
                                                            <h5>Window Type:</h5>
                                                        </div>
                                                        <div class="col-xs-8 col-sm-9">
                                                            <p><?php echo $estate_result1[0]->windowsType; ?></p>
                                                        </div>
                                                    </div>
                                                </div>
												  <div class="col-xs-12">
                                                    <div class="row">
                                                        <div class="col-xs-4 col-sm-3">
                                                            <h5>Chimney Type:</h5>
                                                        </div>
                                                        <div class="col-xs-8 col-sm-9">
                                                            <p><?php echo $estate_result1[0]->chimneyType; ?></p>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-xs-12">
                                                    <div class="row">
                                                        <div class="col-xs-4 col-sm-3">
                                                            <h5>Sewer:</h5>
                                                        </div>
                                                        <div class="col-xs-8 col-sm-9">
                                                            <p><?php echo $estate_result1[0]->drainType; ?></p>
                                                        </div>
                                                    </div>
                                                </div>
												 <div class="col-xs-12">
                                                    <div class="row">
                                                        <div class="col-xs-4 col-sm-3">
                                                            <h5>Water:</h5>
                                                        </div>
                                                        <div class="col-xs-8 col-sm-9">
                                                            <p><?php echo $estate_result1[0]->waterType; ?></p>
                                                        </div>
                                                    </div>
                                                </div>
                                        		<div class="col-xs-12">
                                                    <div class="row">
                                                        <div class="col-xs-4 col-sm-3">
                                                            <h5>Celling:</h5>
                                                        </div>
                                                        <div class="col-xs-8 col-sm-9">
                                                            <p><?php echo $estate_result1[0]->roofingType; ?></p>
                                                        </div>
                                                    </div>
                                                </div>
												  <div class="col-xs-12">
                                                    <div class="row">
                                                        <div class="col-xs-4 col-sm-3">
                                                            <h5>Warming:</h5>
                                                        </div>
                                                        <div class="col-xs-8 col-sm-9">
                                                            <p><?php echo $estate_result1[0]->heatingType; ?></p>
                                                        </div>
                                                    </div>
                                                </div>
                                                  <div class="col-xs-12">
                                                    <div class="row">
                                                        <div class="col-xs-4 col-sm-3">
                                                            <h5>Other Buildings:</h5>
                                                        </div>
                                                        <div class="col-xs-8 col-sm-9">
                                                            <p><?php echo $estate_result1[0]->otherBuildings; ?></p>
                                                        </div>
                                                    </div>
                                                </div>
                                                  <div class="col-xs-12">
                                                    <div class="row">
                                                        <div class="col-xs-4 col-sm-3">
                                                            <h5>Car Parking:</h5>
                                                        </div>
                                                        <div class="col-xs-8 col-sm-9">
                                                            <p><?php echo $estate_result1[0]->parkingSummary; ?></p>
                                                        </div>
                                                    </div>
                                                </div>
                                                  <div class="col-xs-12">
                                                    <div class="row">
                                                        <div class="col-xs-4 col-sm-3">
                                                            <h5>Heating And Ventilation:</h5>
                                                        </div>
                                                        <div class="col-xs-8 col-sm-9">
                                                            <p><?php echo $estate_result1[0]->heatingComment; ?></p>
                                                        </div>
                                                    </div>
                                                </div>
                                                  <div class="col-xs-12">
                                                    <div class="row">
                                                        <div class="col-xs-4 col-sm-3">
                                                            <h5>Internet:</h5>
                                                        </div>
                                                        <div class="col-xs-8 col-sm-9">
                                                            <p><?php echo $estate_result1[0]->internetSummary; ?></p>
                                                        </div>
                                                    </div>
                                                </div>
                                                                      <div class="col-xs-12">
                                                    <div class="row">
                                                        <div class="col-xs-4 col-sm-3">
                                                            <h5>Direction:</h5>
                                                        </div>
                                                        <div class="col-xs-8 col-sm-9">
                                                            <p><?php echo $estate_result1[0]->directions; ?></p>
                                                        </div>
                                                    </div>
                                                </div>
                                                                      <div class="col-xs-12">
                                                    <div class="row">
                                                        <div class="col-xs-4 col-sm-3">
                                                            <h5>The Area:</h5>
                                                        </div>
                                                        <div class="col-xs-8 col-sm-9">
                                                            <p><?php echo $estate_result1[0]->locationComment; ?></p>
                                                        </div>
                                                    </div>
                                                </div>
                                                                      <div class="col-xs-12">
                                                    <div class="row">
                                                        <div class="col-xs-4 col-sm-3">
                                                            <h5>Household Electricity Cost:</h5>
                                                        </div>
                                                        <div class="col-xs-8 col-sm-9">
                                                            <p><?php echo $estate_result1[0]->householdElectricityCost; ?></p>
                                                        </div>
                                                    </div>
                                                </div>
                                                                      <div class="col-xs-12">
                                                    <div class="row">
                                                        <div class="col-xs-4 col-sm-3">
                                                            <h5>Persons In Household:</h5>
                                                        </div>
                                                        <div class="col-xs-8 col-sm-9">
                                                            <p><?php echo $estate_result1[0]->personsInHousehold; ?></p>
                                                        </div>
                                                    </div>
                                                </div>
                                                                      <div class="col-xs-12">
                                                    <div class="row">
                                                        <div class="col-xs-4 col-sm-3">
                                                            <h5>Building Comment:</h5>
                                                        </div>
                                                        <div class="col-xs-8 col-sm-9">
                                                            <p><?php echo $estate_result1[0]->buildingComment; ?></p>
                                                        </div>
                                                    </div>
                                                </div>
                                                                      <div class="col-xs-12">
                                                    <div class="row">
                                                        <div class="col-xs-4 col-sm-3">
                                                            <h5>Other Areas Comment:</h5>
                                                        </div>
                                                        <div class="col-xs-8 col-sm-9">
                                                            <p><?php echo $estate_result1[0]->otherAreasComment; ?></p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
								<div class="col-sm-12">
                                    <div class="broker-tabs">
									   <h3>Energy audits</h3>
                                        <div class="field-names">
                                            <div class="row">
                                                <div class="col-xs-12">
                                                    <div class="row">
                                                        <div class="col-xs-4 col-sm-3">
                                                            <h5>Energy Consumption:</h5>
                                                        </div>
                                                        <div class="col-xs-8 col-sm-9">
                                                            <p><?php echo $building_details[0]->energyConsumption; ?></p>
                                                        </div>
                                                    </div>
                                                </div>
												  <div class="col-xs-12">
                                                    <div class="row">
                                                        <div class="col-xs-4 col-sm-3">
                                                            <h5>Energy Class:</h5>
                                                        </div>
                                                        <div class="col-xs-8 col-sm-9">
                                                            <p><?php echo $building_details[0]->energyClass; ?></p>
                                                        </div>
                                                    </div>
                                                </div>
												  <div class="col-xs-12">
                                                    <div class="row">
                                                        <div class="col-xs-4 col-sm-3">
                                                            <h5>Energy Status:</h5>
                                                        </div>
                                                        <div class="col-xs-8 col-sm-9">
                                                            <p><?php echo $building_details[0]->energyStatus; ?></p>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-xs-12">
                                                    <div class="row">
                                                        <div class="col-xs-4 col-sm-3">
                                                            <h5>Area:</h5>
                                                        </div>
                                                        <div class="col-xs-8 col-sm-9">
                                                            <p><?php echo $building_details[0]->area; ?></p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
								<div class="col-sm-12">
                                    <div class="broker-tabs">
									   <h3>Mortgages</h3>
                                        <div class="field-names">
                                            <div class="row">
                                                <div class="col-xs-12">
                                                    <div class="row">
                                                        <div class="col-xs-4 col-sm-3">
                                                            <h5>Total amount:</h5>
                                                        </div>
                                                        <div class="col-xs-8 col-sm-9">
                                                            <p><?php echo $mortages_details[0]->amount; ?></p>
                                                        </div>
                                                    </div>
                                                </div>
												  <div class="col-xs-12">
                                                    <div class="row">
                                                        <div class="col-xs-4 col-sm-3">
                                                            <h5>Energy Class:</h5>
                                                        </div>
                                                        <div class="col-xs-8 col-sm-9">
                                                            <p><?php echo $mortages_details[0]->displayOrder; ?></p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="broker-form">
                                <h3>Interested?</h3>
                                <form>
                                    <div class="form-group">
                                        <input type="text" placeholder="First Name" class="form-control">
                                    </div>
                                    <div class="form-group">
                                        <input type="text" placeholder="Last Name" class="form-control">
                                    </div>
                                    <div class="form-group">
                                        <input type="text" placeholder="E-post" class="form-control">
                                    </div>
                                    <div class="form-group">
                                        <input type="text" placeholder="Telephone" class="form-control">
                                    </div>
                                    <div class="form-group">
                                        <input type="submit" class="broker-send-btn">
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="clearfix tab-pane" id="Photos">
                <div class="listing-image-gallery">
                    <div class="container">
                        <div class="col-md-12">
                            <div class="broker-tabs">
							<?php
							foreach($estate_img_result as $rowestate_result)
								{
									$estate_images_result = $wpdb->get_results("SELECT * FROM files where id = '".$rowestate_result->fileId."'");
									foreach($estate_images_result as $rowIMAGES)
									{
										echo "<div class='broker-photos'><img src='".$rowIMAGES->viewURI."' border='0'  /><br>
												</div>";
									}
								}
				
							?>
								
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="clearfix tab-pane" id="Plan">
                <div class="listing-image-gallery">
                    <div class="container">
                        <div class="col-md-12">
                            <div class="broker-tabs">
                                <div class="broker-photos">
							<?php
							foreach($estate_img_result_plan as $rowestate_result_plan)
								{
									$estate_images_result_pln = $wpdb->get_results("SELECT * FROM files where id = '".$rowestate_result_plan->fileId."'");
									foreach($estate_images_result_pln as $row_plan_IMAGES)
									{
										echo "<div class='broker-photos'><img src='".$row_plan_IMAGES->viewURI."' border='0'  /><br>
												</div>";
									}
								}
				
							?>                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="clearfix tab-pane" id="Map">
                <div class="listing-image-gallery">
                    <div class="container">
                        <div class="col-md-12">
                            <div class="broker-tabs">
                                <h3>Location of </h3>
                                <?php
                                //foreach ($estate_result as $estate_result1) {?>
                                <?php
                                //$address    = trim(urlencode($estate_result1->streetAddress));
                                //$city         = trim(urlencode($estate_result1->city));
                                //$state         = trim(urlencode($listing['State']));
                                //$country      = trim(urlencode('United States'));
                                //$zip         = trim(urlencode($estate_result1->postalCode));
                                //echo $address,$city,$zip;

                                //$geocode    =    file_get_contents('http://maps.google.com/maps/api/geocode/json?address='.$address.',+'.$city.',+'.$zip.'');

                                //$output        = json_decode($geocode); //Store values in variable
                                //print_r($output);
                                //if($output->status == 'OK'){ // Check if address is available or not
                                    $latitude = $estate_result1[0]->latitude; //Returns Latitude
                                   
                                    $longitude = $estate_result1[0]->longitude; // Returns Longitude
                                //echo $latitude,$longitude;
                                /*}
                                else {
                                    echo "Sorry we can't find this location.Check the details again!";
                                }*/
                                ?>
                                <?php// } ?>
                                <div id="map" style="width:100%;height:550px;  margin:20px auto 0;"></div>
                            </div>
                        </div>
                    </div>
                    <script type="text/javascript">
                        $(document).ready(function () {
                            //alert("ajalkjxslaJ");
                            // Define the latitude and longitude positions
                            var latitude = parseFloat("<?php echo $latitude; ?>"); // Latitude get from above variable
                            var longitude = parseFloat("<?php echo $longitude; ?>"); // Longitude from same
                            var latlngPos = new google.maps.LatLng(latitude, longitude);
                           
                            // Set up options for the Google map
                            var myOptions = {
                                zoom: 14,
                                center: latlngPos,
                                mapTypeId: google.maps.MapTypeId.ROADMAP,
                                zoomControlOptions: true,
                                zoomControlOptions: {
                                    style: google.maps.ZoomControlStyle.LARGE
                                }
                            };
                           
                            // Define the map
                            map = new google.maps.Map(document.getElementById("map"), myOptions);
                           
                            // Add the marker
                            var marker = new google.maps.Marker({
                                position: latlngPos,
                                map: map,
                                title: "Your Location"
                            });
                           
                        });
                    </script>
                </div>
            </div>
        </div>
    </section>
</div>

<div class="broker-agent-section">
    <div class="container">
        <div class="row">
            <div class="col-xs-12">
                <div class="row">
                    <div class="col-xs-12">
                        <div class="row">
                            <div class="agent-detail-broker">
                                <h1>Responsible Broker</h1>
                                <div class="agent-image">
                                    <img src="<?php bloginfo("template_directory"); ?>/assets/img/askengren1.jpg" />
                                </div>
                                <div class="agent-detail">
                                    <h3>Name: <?php echo $brocker_data[0]->firstName.' '.$brocker_data[0]->lastName;?></h3>
                                    <p>Email: <?php echo $brocker_data[0]->email;?></p>
                                    <p>Phone: <?php echo $brocker_data[0]->phoneNumber;?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<?php get_footer();?>
