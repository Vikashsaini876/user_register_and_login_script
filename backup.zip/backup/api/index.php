<?php
$link = mysqli_connect("mysql14.ilait.se", "udmyks232223", "th7qDUgot", "dks116671");

//$link = mysqli_connect("localhost", "root", "123", "mspec");

if (!$link) {
    echo "Error: Unable to connect to MySQL." . PHP_EOL;
    echo "Debugging errno: " . mysqli_connect_errno() . PHP_EOL;
    echo "Debugging error: " . mysqli_connect_error() . PHP_EOL;
    exit;
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Property</title>
	<link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet"> 
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/style.css">
</head>
<body>
	<div id="container">
		<header>
			<div class="logo-menu">
				<div class="container">
					<div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
						<div class="row">
							<div class="col-md-4">
								<div class="row">
									<div class="navbar-brand">
										<a href="index.php">
											<h3>Property</h3>
										</a>
									</div>
								</div>
							</div>
							<div class="col-md-8">
								<div class="menubar">
									<nav class="navbar navbar-default">
										<div class="">
											<div class="navbar-header">
										      	<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
											        <span class="sr-only">Toggle navigation</span>
											        <span class="icon-bar"></span>
											        <span class="icon-bar"></span>
											        <span class="icon-bar"></span>
										      	</button>	
				    						</div>
				    						<div class="collapse navbar-collapse menu" id="bs-example-navbar-collapse-1">
												<ul class="nav navbar-nav menu pull-right">
													<li><a class="active" href="index.php">HOME</a></li>
													<li><a href="#">ABOUT US</a></li>
													<li><a href="#">CONTACT US</a></li>
												</ul>
											</div>
										</div>
									</nav>
								</div>	
							</div>
						</div>
					</div>
				</div>
			</div>
		</header>
		<style>
			
#country-list {
  background: #fff none repeat scroll 0 0;
  border: 2px solid #c5c5c5;
  height: 130px;
  list-style: outside none none;
  margin: 0 auto;
  overflow-y: scroll;
  padding: 0;
  text-align: left;
  width: 44.5%;
}
			
#country-list li {
  background: #f7f8fc none repeat scroll 0 0;
  margin-bottom: 2px;
  padding: 6px 10px;
}
			
#country-list li a {
  color: #555;
}

			.go-btn {
			  width: 50px !important;
			}
			
		</style>
		<?php 
		 $s1 = $_GET['search_field'];
		$s2 = $_GET['price'];
		 $addSearch .=" displayName like '".$s1."%' and startingPrice like '".$s2."%'";
			//echo "SELECT * FROM deals where $addSearch ORDER BY id";
		
		 $new_result = mysqli_query($link, "SELECT * FROM deals where $addSearch ORDER BY id");
	 	 $menu_bar_search_num = mysqli_num_rows($new_result);
		?>
		<div class="searchbar">
			<div class="container">
				<form action="" method="GET"> 
				<div class="searchbox">
					<input type="text" width="20%" class="price_search" name="price" placeholder="enter price" autocomplete="off" value="<?php echo $_GET['price'];?>" ><div id="price_list_box"></div>
					<input type="text" class="search_input" name="search_field" autocomplete="off" placeholder="Search your listing here" value="<?php echo $_GET['search_field'];?>" ><input class="go-btn" type="submit" value="Go"><div id="advance_search_list_box"></div>
					
				</div>
				</form>	
			</div>
		</div>
		<div class="listing-section">
			<div class="container">
				<div class="row">
					<div class="col-xs-12">
						<div class="row">
						<?php 
							while($row = mysqli_fetch_array($new_result))
							{
                              $primaryId = $row['id'];  
                              // echo "SELECT * FROM filesInDeals as s JOIN files as c where s.fileId=c.id and s.dealId= '$primaryId' and c.viewURI !=''";
                             
                            $result_files_in_deals = mysqli_query($link, "SELECT * FROM filesInDeals as s JOIN files as c where s.fileId=c.id and s.dealId= '$primaryId' and c.viewURI !=''");   
                            $row_files_in_deals = mysqli_fetch_array($result_files_in_deals);
                              //  echo "<pre>";print_r($row_files_in_deals);    
                            
                            //$result_files_in_deals = mysqli_query($link, "SELECT * FROM filesInDeals where dealId= '$primaryId' ORDER BY id");   
                           // $row_files_in_deals = mysqli_fetch_array($result_files_in_deals);
                           // $fileurl = $row_files_in_deals['fileId'];
                             
                          //  $result_files = mysqli_query($link, "SELECT * FROM files where id= '$fileurl'");     
//$row_files = mysqli_fetch_array($result_files);
                                //echo "<pre>";print_r($row_files);
                            ?>
							<div class="col-sm-4">
								<div class="single-listing">
							<?php 
							 if($row_files_in_deals['viewURI'] !='')
							 {
							 ?>
									<img src="<?php echo $row_files_in_deals['viewURI'];?>" class="image">
							 <?php
							 }
							 else
							 {	  
							 ?>
								<img src="img/no-image.jpg" class="image">
							 <?php
							 }
							 ?>
									<div class="overlay">
									    <div class="text">
									    	<h3><?php echo $row['displayName'];?></h3>
									    	<?php if($row['streetAddress'] !=''){ ?> <h5><?php echo $row['streetAddress'];?></h5><?php } ?>
                                            <?php 
							 if($row_files_in_deals['originalURI'] !='')
							 {
							 ?>
                                            <p><a href="<?php echo $row_files_in_deals['originalURI'];?>" target="_blank">PDF</a></p>
							 <?php
							 }
                                ?>
									    	<p>Price : <?php echo $row['startingPrice'];?></p>
									    <?php if($row['webPageURL'] !='') {?><a href="<?php echo $row['webPageURL'];?>">Get more details</a><?php } ?>
									    </div>
									</div>
								</div>
							</div>
							<?php
							}?>
							
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</body>
</html>


<script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.2.0.min.js"></script>

<script>
$(document).ready(function() {        
$(".search_input").keyup(function(){
        $.ajax({
        type: "POST",
        url: "demo.php?request=search_list",
        data:'keyword='+$(this).val(),
        beforeSend: function(){
            $(".loader-wrapper").show();
        },
        success: function(data){
			//alert(data);
            $(".loader-wrapper").hide();
            $("#advance_search_list_box").show();
            $("#advance_search_list_box").html(data);
            window.setTimeout(function(){
        	$("#country-list").hide();
             }, 1500);    
            //$("#pro-list").hide();     
        }
        });
       
    });
	
	$(".price_search").keyup(function(){
        $.ajax({
        type: "POST",
        url: "demo.php?request=price_list",
        data:'keyword='+$(this).val(),
        beforeSend: function(){
            $(".loader-wrapper").show();
        },
        success: function(data){
			//alert(data);
            $(".loader-wrapper").hide();
            $("#price_list_box").show();
            $("#price_list_box").html(data);
           /* window.setTimeout(function(){
        	$("#country-list1").hide();
             }, 500);    */
            //$("#pro-list").hide();     
        }
        });
       
    });
        
});
        
function select_list(val) {
   // alert(val);
$(".search_input").val(val);
$("#advance_search_list_box").hide();
}

	function select_price_list(val1) {
   // alert(val);
$(".price").val(val1);
$("#price_list_box").hide();
}
	
	
</script>