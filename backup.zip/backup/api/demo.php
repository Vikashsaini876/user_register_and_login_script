<?php
	$link = mysqli_connect("mysql14.ilait.se", "udmyks232223", "th7qDUgot", "dks116671");

//$link = mysqli_connect("localhost", "root", "123", "mspec");
if (!$link) {
    echo "Error: Unable to connect to MySQL." . PHP_EOL;
    echo "Debugging errno: " . mysqli_connect_errno() . PHP_EOL;
    echo "Debugging error: " . mysqli_connect_error() . PHP_EOL;
    exit;
}
?>
<style>
	#country-list {
  height: 130px;
  list-style: outside none none;
  margin: 0 auto;
  overflow-y: scroll;
  padding: 0 14px;
  width: 35%;
}
#country-list li {
  padding: 5px 0;
}
	#country-list1 {
  height: 130px;
  list-style: outside none none;
  margin: 0 auto;
  overflow-y: scroll;
  padding: 0 14px;
  width: 35%;
}
#country-list1 li {
  padding: 5px 0;
}
</style>	
<?php

if($_REQUEST['request']=='search_list'){
	
	$kk = $_POST;
	//print_r($kk);
	
	$s1 = $kk['search_field'];
	
	$addSearch .=" displayName like '".$s1."%' ";
		
	$new_result = mysqli_query($link, "SELECT * FROM deals where $addSearch ORDER BY id");
	 $menu_bar_search_num = mysqli_num_rows($new_result);
		
	if(!empty($menu_bar_search_num)) {
?>

<ul id="country-list">
<?php
foreach($new_result as $country) {
	
?>	
<li ><a onClick="select_list('<?php echo $country["displayName"]; ?>');"><?php echo $country["displayName"]; ?></a></li>
<?php
} ?>
</ul>
<?php }
	else
	{
	echo  "<ul id='country-list'><li><a >No Records Found</a></li></ul>";
	}		
	
}
else if($_REQUEST['request']=='price_list'){
	
	$kk = $_POST;
	//print_r($kk);
	
	$s1 = $kk['price'];
	
	$addSearch .=" startingPrice like '".$s1."%' ";
		
	$new_result = mysqli_query($link, "SELECT * FROM deals where $addSearch ORDER BY id");
	 $menu_bar_search_num = mysqli_num_rows($new_result);
		
	if(!empty($menu_bar_search_num)) {
?>

<ul id="country-list1">
<?php
foreach($new_result as $country) {
	
?>	
<li ><a onClick="select_price_list('<?php echo $country["startingPrice"]; ?>');"><?php echo $country["startingPrice"]; ?></a></li>
<?php
} ?>
</ul>
<?php }
	else
	{
	echo  "<ul id='country-list1'><li><a >No Records Found</a></li></ul>";
	}		
	
}

?>