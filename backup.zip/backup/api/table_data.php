<?php
$con = mysqli_connect("mysql14.ilait.se", "udmyks232223", "th7qDUgot", "dks116671");
//$con = mysqli_connect("localhost", "root", "123", "mspec");

if (!$con) {
    echo "Error: Unable to connect to MySQL." . PHP_EOL;
    echo "Debugging errno: " . mysqli_connect_errno() . PHP_EOL;
    echo "Debugging error: " . mysqli_connect_error() . PHP_EOL;
    exit;
}

if($_REQUEST['type'] == 'estates')
{
	
$username = "apiaskengren@kustit.se";
$password = "apipasswordaskengren2017";
$postUrl = "https://api.mspecs.se/estates?fields=id,dealId,mainImageFileId,buildingArea,totalLivingArea,totalArea,propertyName,numberOfRoom,roomsDescription,numberOfBedrooms,district,streetAddress,postalCode,city,latitude,longitude,description,plotDescription,buildYear,otherLivingArea,assessValueBuilding,assessValueLand,assessValueTotal,housingAssociationName,apartmentNumber,shareInCondo,ventilationType,windowsType,chimneyType,drainType,waterType,roofingType,heatingType,otherBuildings,parkingSummary,heatingComment,internetSummary,directions,locationComment,householdElectricityCost,personsInHousehold,buildingComment,otherAreasComment";

// Create a stream
$opts = array(
  'http'=>array(
    'method'=>"GET",
    'header' => "Authorization: Basic " . base64_encode("$username:$password")                 
  )
);
$context = stream_context_create($opts);
// Open the file using the HTTP headers set above
$file = file_get_contents($postUrl, false, $context);
$array = json_decode($file,true); 


mysqli_query($con,"TRUNCATE TABLE estates");
    
foreach($array as $row)
{   

  mysqli_query($con,"INSERT INTO estates(id,dealId,mainImageFileId,buildingArea,totalLivingArea,totalArea,propertyName,numberOfRoom,roomsDescription,numberOfBedrooms,district,streetAddress,postalCode,city,latitude,longitude,description,plotDescription,buildYear,otherLivingArea,assessValueBuilding,assessValueLand,assessValueTotal,housingAssociationName,apartmentNumber,shareInCondo,ventilationType,windowsType,chimneyType,drainType,waterType,roofingType,heatingType,otherBuildings,parkingSummary,heatingComment,internetSummary,directions,locationComment,householdElectricityCost,personsInHousehold,buildingComment,otherAreasComment)VALUES('$row[id]','$row[dealId]','$row[mainImageFileId]','$row[buildingArea]','$row[totalLivingArea]','$row[totalArea]','$row[propertyName]','$row[numberOfRoom]','$row[roomsDescription]','$row[numberOfBedrooms]','$row[district]','$row[streetAddress]','$row[postalCode]','$row[city]','$row[latitude]','$row[longitude]','$row[description]','$row[plotDescription]','$row[buildYear]','$row[otherLivingArea]','$row[assessValueBuilding]','$row[assessValueLand]','$row[assessValueTotal]',
'$row[housingAssociationName]','$row[apartmentNumber]','$row[shareInCondo]','$row[ventilationType]',
'$row[windowsType]','$row[chimneyType]','$row[drainType]','$row[waterType]','$row[roofingType]','$row[heatingType]',
'$row[otherBuildings]','$row[parkingSummary]','$row[heatingComment]','$row[internetSummary]','$row[directions]',
'$row[locationComment]','$row[householdElectricityCost]','$row[personsInHousehold]',
'$row[buildingComment]','$row[otherAreasComment]')");
}  

}
else if($_REQUEST['type'] == 'files')
{
$username = "apiaskengren@kustit.se";
$password = "apipasswordaskengren2017";
$postUrl = "https://api.mspecs.se/files?fields=id,viewURI,viewResolution,thumbnailURI,thumbnailResolution,deleteURI,originalURI,originalResolution,fileSize,displayOrder,title,fileCategoryId,description,isImage,isPublished,isMarketing,createdByUserId,updatedDate";
        
// Create a stream
$opts = array(
  'http'=>array(
    'method'=>"GET",
    'header' => "Authorization: Basic " . base64_encode("$username:$password")                 
  )
);

$context = stream_context_create($opts);
$file = file_get_contents($postUrl, false, $context);
$array = json_decode($file,true); 
print_r($array);


mysqli_query($con,"TRUNCATE TABLE files");    

foreach($array as $row)
{   	
  $sql = mysqli_query($con,"INSERT INTO files(id,viewURI,viewResolution,thumbnailURI,thumbnailResolution,deleteURI,originalURI,originalResolution,fileSize,displayOrder,title,fileCategoryId,description,isImage,isPublished,isMarketing,createdByUserId,updatedDate)    VALUES('$row[id]','$row[viewURI]','$row[viewResolution]','$row[thumbnailURI]','$row[thumbnailResolution]','$row[deleteURI]','$row[originalURI]','$row[originalResolution]','$row[fileSize]','$row[displayOrder]','$row[title]','$row[fileCategoryId]','$row[description]','$row[isImage]','$row[isPublished]','$row[isMarketing]','$row[createdByUserId]','$row[updatedDate]')");
}
    
}
else if($_REQUEST['type'] == 'deals')
{
$username = "apiaskengren@kustit.se";
$password = "apipasswordaskengren2017";
$postUrl = "https://api.mspecs.se/deals?fields=id,buyerGroupId,objectStatus,communicationTokenId,assignmentType,mainEstateId,mainBrokerContactId,capitalGainCalculationId,webPageURL,webPageImagesURL,webPageAccessibleOnlyByDirectUrl,contractType,organizationUnitId,currentFlowStepId,biddingId,mainImageFileId,currency,sellingTextSubject,sellingTextShort,sellingText,externalId,displayName,listingStartDate,listingEndDate,listingReservedEndDate,listingReservedStartDate,contractDate,downPaymentDate,downPaymentAmount,isDownPaymentDepositedWithBroker,isDownPaymentInBrokerClientAccount,downPaymentAccountId,depositedInAmount,depositedInDate,depositedInComment,allConditionsMetDate,legalEntityAcceptableSetting,isVIP,isBuyerApprovedByTennant,buyerApprovedByTennantDate,buyerApprovalByTennantSentDate,archiveNumber,accessDate,accessComment,accessDateSeller,accessDateBuyer,accessNoticeToSeller,accessNoticeToBuyer,cashDefinitiveStatementComment,startingPrice,finalPrice,finalPriceInText,startingPriceType,foreignStartingPrice,foreignStartingPriceCurrencyId,abortionCompensation,vatPercentage,isInternational,approveMarketingOfFinalPrice,approveMarketingOfDeal,archiveExternalId,buyersPartOfMonthlyRent,buyersPartOfMunicipalPropertyTax,outgoingDownPaymentTransactionGroupId,incomingPaymentTransactionGroupId,outgoingPaymentTransactionGroupId,outgoingPaymentBankAccountId,outgoingPaymentBankAccountText,energyStatus,energyDeclarationAmount,energyStatusDeadlineDate,accessLocation,accessOfficer,commissionId,description,identifier,cashDefinitiveStatementCommentSeller,cashDefinitiveStatementCommentBuyer,cashDefinitiveStatementFeeAndTaxInformation,importedDate,importedName,sellingMethodIsQuotation,sellingMethodQuotationDateTime,sellingMethodIsBid,sellingMethodBidDateTime,sellingMethodIsInterest,sellingMethodInterestDateTime,sellingMethodIsFixedPrice,sellingMethodIsOpenBidding,sellingMethodIsPublicAuction,sellingMethodPublicAuctionDateTime,sellingMethodDescription,sellingMethodTermsOfPayment,isNewDevelopment,newDevelopmentStatus,streetAddress,postalCode,city,builder,minNumberOfRooms,maxNumberOfRooms,minLivingArea,maxLivingArea,minPrice,maxPrice,numberOfHomes,environment,servicesAndCommunications,directions,latitude,longitude,buildingStarted,preliminaryOccupancy,plotArea,plotDescription,developmentPhase,objectType,habitat,salesStartDate,objectTypeId,accessOfficerContactId,accessLocationContactId,earliestAccessDateComment,sellAsCompany,assignmentIsTerminated,assignmentTerminatedDate,assignmentTerminatedReason,quotationDueDate,quotationComment,sellerSignatureLocation,buyerSignatureLocation,isPublishedOnHemnet,publishedOnHemnetDate,isPublished,municipalPropertyTax,isAcceptedStartingPrice,isSoldByQuotation,optionalEquipmentValue,optionalEquipmentComment,incomingPartialPaymentDate,incomingPartialPaymentAmount,outgoingPartialPaymentDate,outgoingPartialPaymentAmount,interestRate,interestRateStartDate,interestRateEndDate,isInterestRateAndDepositInSettlement,downPaymentAmountInText,matchingId,depositedOutDate,depositedOutComment,isLegalEntityOK,depositedOutAmount,buildingStartDate,preliminaryOccupancyStartDate,updatedDate";
        
// Create a stream
$opts = array(
  'http'=>array(
    'method'=>"GET",
    'header' => "Authorization: Basic " . base64_encode("$username:$password")                 
  )
);

$context = stream_context_create($opts);
// Open the file using the HTTP headers set above
$file = file_get_contents($postUrl, false, $context);
$array = json_decode($file,true);    
mysqli_query($con,"TRUNCATE TABLE deals");
    
foreach($array as $row)
{   
  $sql = mysqli_query($con,"INSERT INTO deals(id,buyerGroupId,objectStatus,communicationTokenId,assignmentType,mainEstateId,mainBrokerContactId,capitalGainCalculationId,webPageURL,webPageImagesURL,webPageAccessibleOnlyByDirectUrl,contractType,organizationUnitId,currentFlowStepId,biddingId,mainImageFileId,currency,sellingTextSubject,sellingTextShort,sellingText,externalId,displayName,listingStartDate,listingEndDate,listingReservedEndDate,listingReservedStartDate,contractDate,downPaymentDate,downPaymentAmount,isDownPaymentDepositedWithBroker,isDownPaymentInBrokerClientAccount,downPaymentAccountId,depositedInAmount,depositedInDate,depositedInComment,allConditionsMetDate,legalEntityAcceptableSetting,isVIP,isBuyerApprovedByTennant,buyerApprovedByTennantDate,buyerApprovalByTennantSentDate,archiveNumber,accessDate,accessComment,accessDateSeller,accessDateBuyer,accessNoticeToSeller,accessNoticeToBuyer,cashDefinitiveStatementComment,startingPrice,finalPrice,finalPriceInText,startingPriceType,foreignStartingPrice,foreignStartingPriceCurrencyId,abortionCompensation,vatPercentage,isInternational,approveMarketingOfFinalPrice,approveMarketingOfDeal,archiveExternalId,buyersPartOfMonthlyRent,buyersPartOfMunicipalPropertyTax,outgoingDownPaymentTransactionGroupId,incomingPaymentTransactionGroupId,outgoingPaymentTransactionGroupId,outgoingPaymentBankAccountId,outgoingPaymentBankAccountText,energyStatus,energyDeclarationAmount,energyStatusDeadlineDate,accessLocation,accessOfficer,commissionId,description,identifier,cashDefinitiveStatementCommentSeller,cashDefinitiveStatementCommentBuyer,cashDefinitiveStatementFeeAndTaxInformation,importedDate,importedName,sellingMethodIsQuotation,sellingMethodQuotationDateTime,sellingMethodIsBid,sellingMethodBidDateTime,sellingMethodIsInterest,sellingMethodInterestDateTime,sellingMethodIsFixedPrice,sellingMethodIsOpenBidding,sellingMethodIsPublicAuction,sellingMethodPublicAuctionDateTime,sellingMethodDescription,sellingMethodTermsOfPayment,isNewDevelopment,newDevelopmentStatus,streetAddress,postalCode,city,builder,minNumberOfRooms,maxNumberOfRooms,minLivingArea,maxLivingArea,minPrice,maxPrice,numberOfHomes,environment,servicesAndCommunications,directions,latitude,longitude,buildingStarted,preliminaryOccupancy,plotArea,plotDescription,developmentPhase,objectType,habitat,salesStartDate,objectTypeId,accessOfficerContactId,accessLocationContactId,earliestAccessDateComment,sellAsCompany,assignmentIsTerminated,assignmentTerminatedDate,assignmentTerminatedReason,quotationDueDate,quotationComment,sellerSignatureLocation,buyerSignatureLocation,isPublishedOnHemnet,publishedOnHemnetDate,isPublished,municipalPropertyTax,isAcceptedStartingPrice,isSoldByQuotation,optionalEquipmentValue,optionalEquipmentComment,incomingPartialPaymentDate,incomingPartialPaymentAmount,outgoingPartialPaymentDate,outgoingPartialPaymentAmount,interestRate,interestRateStartDate,interestRateEndDate,isInterestRateAndDepositInSettlement,downPaymentAmountInText,matchingId,depositedOutDate,depositedOutComment,isLegalEntityOK,depositedOutAmount,buildingStartDate,preliminaryOccupancyStartDate,updatedDate)    VALUES('$row[id]','$row[buyerGroupId]','$row[objectStatus]','$row[communicationTokenId]','$row[assignmentType]','$row[mainEstateId]','$row[mainBrokerContactId]','$row[capitalGainCalculationId]','$row[webPageURL]','$row[webPageImagesURL]','$row[webPageAccessibleOnlyByDirectUrl]','$row[contractType]','$row[organizationUnitId]','$row[currentFlowStepId]','$row[biddingId]','$row[mainImageFileId]','$row[currency]','$row[sellingTextSubject]','$row[sellingTextShort]','$row[sellingText]','$row[externalId]','$row[displayName]','$row[listingStartDate]','$row[listingEndDate]','$row[listingReservedEndDate]','$row[listingReservedStartDate]','$row[contractDate]','$row[downPaymentDate]','$row[downPaymentAmount]','$row[isDownPaymentDepositedWithBroker]','$row[isDownPaymentInBrokerClientAccount]','$row[downPaymentAccountId]','$row[depositedInAmount]','$row[depositedInDate]','$row[depositedInComment]','$row[allConditionsMetDate]','$row[legalEntityAcceptableSetting]','$row[isVIP]','$row[isBuyerApprovedByTennant]','$row[buyerApprovedByTennantDate]','$row[buyerApprovalByTennantSentDate]','$row[archiveNumber]','$row[accessDate]','$row[accessComment]','$row[accessDateSeller]','$row[accessDateBuyer]','$row[accessNoticeToSeller]','$row[accessNoticeToBuyer]','$row[cashDefinitiveStatementComment]','$row[startingPrice]','$row[finalPrice]','$row[finalPriceInText]','$row[startingPriceType]','$row[foreignStartingPrice]','$row[foreignStartingPriceCurrencyId]','$row[abortionCompensation]','$row[vatPercentage]','$row[isInternational]','$row[approveMarketingOfFinalPrice]','$row[approveMarketingOfDeal]','$row[archiveExternalId]','$row[buyersPartOfMonthlyRent]','$row[buyersPartOfMunicipalPropertyTax]','$row[outgoingDownPaymentTransactionGroupId]','$row[incomingPaymentTransactionGroupId]','$row[outgoingPaymentTransactionGroupId]','$row[outgoingPaymentBankAccountId]','$row[outgoingPaymentBankAccountText]','$row[energyStatus]','$row[energyDeclarationAmount]','$row[energyStatusDeadlineDate]','$row[accessLocation]','$row[accessOfficer]','$row[commissionId]','$row[description]','$row[identifier]','$row[cashDefinitiveStatementCommentSeller]','$row[cashDefinitiveStatementCommentBuyer]','$row[cashDefinitiveStatementFeeAndTaxInformation]','$row[importedDate]','$row[importedName]','$row[sellingMethodIsQuotation]','$row[sellingMethodQuotationDateTime]','$row[sellingMethodIsBid]','$row[sellingMethodBidDateTime]','$row[sellingMethodIsInterest]','$row[sellingMethodInterestDateTime]','$row[sellingMethodIsFixedPrice]','$row[sellingMethodIsOpenBidding]','$row[sellingMethodIsPublicAuction]','$row[sellingMethodPublicAuctionDateTime]','$row[sellingMethodDescription]','$row[sellingMethodTermsOfPayment]','$row[isNewDevelopment]','$row[newDevelopmentStatus]','$row[streetAddress]','$row[postalCode]','$row[city]','$row[builder]','$row[minNumberOfRooms]','$row[maxNumberOfRooms]','$row[minLivingArea]','$row[maxLivingArea]','$row[minPrice]','$row[maxPrice]','$row[numberOfHomes]','$row[environment]','$row[servicesAndCommunications]','$row[directions]','$row[latitude]','$row[longitude]','$row[buildingStarted]','$row[preliminaryOccupancy]','$row[plotArea]','$row[plotDescription]','$row[developmentPhase]','$row[objectType]','$row[habitat]','$row[salesStartDate]','$row[objectTypeId]','$row[accessOfficerContactId]','$row[accessLocationContactId]','$row[earliestAccessDateComment]','$row[sellAsCompany]','$row[assignmentIsTerminated]','$row[assignmentTerminatedDate]','$row[assignmentTerminatedReason]','$row[quotationDueDate]','$row[quotationComment]','$row[sellerSignatureLocation]','$row[buyerSignatureLocation]','$row[isPublishedOnHemnet]','$row[publishedOnHemnetDate]','$row[isPublished]','$row[municipalPropertyTax]','$row[isAcceptedStartingPrice]','$row[isSoldByQuotation]','$row[optionalEquipmentValue]','$row[optionalEquipmentComment]','$row[incomingPartialPaymentDate]','$row[incomingPartialPaymentAmount]','$row[outgoingPartialPaymentDate]','$row[outgoingPartialPaymentAmount]','$row[interestRate]','$row[interestRateStartDate]','$row[interestRateEndDate]','$row[isInterestRateAndDepositInSettlement]','$row[downPaymentAmountInText]','$row[matchingId]','$row[depositedOutDate]','$row[depositedOutComment]','$row[isLegalEntityOK]','$row[depositedOutAmount]','$row[buildingStartDate]','$row[preliminaryOccupancyStartDate]','$row[updatedDate]')");
}

}
else if($_REQUEST['type'] == 'files')
{
$username = "apiaskengren@kustit.se";
$password = "apipasswordaskengren2017";
$postUrl = "https://api.mspecs.se/files?fields=id,viewURI,viewResolution,thumbnailURI,thumbnailResolution,deleteURI,originalURI,originalResolution,fileSize,displayOrder,title,fileCategoryId,description,isImage,isPublished,isMarketing,createdByUserId,updatedDate";
        
// Create a stream
$opts = array(
  'http'=>array(
    'method'=>"GET",
    'header' => "Authorization: Basic " . base64_encode("$username:$password")                 
  )
);

$context = stream_context_create($opts);
$file = file_get_contents($postUrl, false, $context);
$array = json_decode($file,true); 
print_r($array);


//mysqli_query($con,"TRUNCATE TABLE files");    

foreach($array as $row)
{   	
  $sql = mysqli_query($con,"INSERT INTO files(id,viewURI)VALUES('$row[id]','$row[viewURI]')");
}
    
}
else if($_REQUEST['type'] == 'filesInDeals')
{
$username = "apiaskengren@kustit.se";
$password = "apipasswordaskengren2017";
$postUrl = "https://api.mspecs.se/filesInDeals?fields=id,fileId,dealId,updatedDate";
// Create a stream
$opts = array(
  'http'=>array(
    'method'=>"GET",
    'header' => "Authorization: Basic " . base64_encode("$username:$password")                 
  )
);
$context = stream_context_create($opts);
// Open the file using the HTTP headers set above
$file = file_get_contents($postUrl, false, $context);
$array = json_decode($file,true); 
mysqli_query($con,"TRUNCATE TABLE filesInDeals");
    
foreach($array as $row)
{   	
  $sql = mysqli_query($con,"INSERT INTO filesInDeals(id,fileId,dealId,updatedDate)    VALUES('$row[id]','$row[fileId]','$row[dealId]','$row[updatedDate]')");
}
    
}

else if($_REQUEST['type'] == 'contacts')
{
$username = "apiaskengren@kustit.se";
$password = "apipasswordaskengren2017";
$postUrl = "https://api.mspecs.se/contacts?fields=id,userAccountId,identifier,extraIdentifier,title,firstName,lastName,co,gender,bookkeepingAccountNr,companyName,streetAddress,postalCode,city,email,phoneNumber,homePhoneNumber,faxNumber,isSmsNumber,websiteUrl,countryId,registeredResidenceCountryId,passportNumber,birthDate,description,createdDate,createdByUserId,isLegalEntity,profilePictureId,languageId,PUL,initials,PULsetDate,contactBranchId,noCommercialInformation,fullNameAuthorizedToSignForCompany,authorizedToSignForCompanyControlledBy,workTitle,newDevelopmentDealId,housingAssociationId,alias,isExternalContact,externalId,tags,ignoreDuplicateCheck,isDeceased,hasSecretIdentity,contactSecretIdentityId,updatedDate";
// Create a stream
$opts = array(
  'http'=>array(
    'method'=>"GET",
    'header' => "Authorization: Basic " . base64_encode("$username:$password")                 
  )
);
$context = stream_context_create($opts);
// Open the file using the HTTP headers set above
$file = file_get_contents($postUrl, false, $context);
$array = json_decode($file,true); 
mysqli_query($con,"TRUNCATE TABLE contacts");
    
foreach($array as $row)
{   	
  $sql = mysqli_query($con,"INSERT INTO contacts(id,userAccountId,identifier,extraIdentifier,title,firstName,lastName,co,gender,bookkeepingAccountNr,companyName,streetAddress,postalCode,city,email,phoneNumber,homePhoneNumber,faxNumber,isSmsNumber,websiteUrl,countryId,registeredResidenceCountryId,passportNumber,birthDate,description,createdDate,createdByUserId,isLegalEntity,profilePictureId,languageId,PUL,initials,PULsetDate,contactBranchId,noCommercialInformation,fullNameAuthorizedToSignForCompany,authorizedToSignForCompanyControlledBy,workTitle,newDevelopmentDealId,housingAssociationId,alias,isExternalContact,externalId,tags,ignoreDuplicateCheck,isDeceased,hasSecretIdentity,contactSecretIdentityId,updatedDate)    VALUES('$row[id]','$row[userAccountId]','$row[identifier]','$row[extraIdentifier]','$row[title]','$row[firstName]','$row[lastName]','$row[co]','$row[gender]','$row[bookkeepingAccountNr]','$row[companyName]','$row[streetAddress]','$row[postalCode]','$row[city]','$row[email]','$row[phoneNumber]','$row[homePhoneNumber]','$row[faxNumber]','$row[isSmsNumber]','$row[websiteUrl]','$row[countryId]','$row[registeredResidenceCountryId]','$row[passportNumber]','$row[birthDate]','$row[description]','$row[createdDate]','$row[createdByUserId]','$row[isLegalEntity]','$row[profilePictureId]','$row[languageId]','$row[PUL]','$row[initials]','$row[PULsetDate]','$row[contactBranchId]','$row[noCommercialInformation]','$row[fullNameAuthorizedToSignForCompany]','$row[authorizedToSignForCompanyControlledBy]','$row[workTitle]','$row[newDevelopmentDealId]','$row[housingAssociationId]','$row[alias]','$row[isExternalContact]','$row[externalId]','$row[tags]','$row[ignoreDuplicateCheck]','$row[isDeceased]','$row[hasSecretIdentity]','$row[contactSecretIdentityId]','$row[updatedDate]')");
}  
}


else if($_REQUEST['type'] == 'sellers')
{
$username = "apiaskengren@kustit.se";
$password = "apipasswordaskengren2017";
$postUrl = "https://api.mspecs.se/sellers?fields=id,contactId,dealId,share,spouseConsentSignature,displayOrder,sendBiddingInformationBySMS,sendBiddingInformationByEmail,shouldNotSign,isDeceasedInheritor,updatedDate";
// Create a stream
$opts = array(
  'http'=>array(
    'method'=>"GET",
    'header' => "Authorization: Basic " . base64_encode("$username:$password")                 
  )
);
$context = stream_context_create($opts);
// Open the file using the HTTP headers set above
$file = file_get_contents($postUrl, false, $context);
$array = json_decode($file,true); 
mysqli_query($con,"TRUNCATE TABLE sellers");
    
foreach($array as $row)
{   	
  $sql = mysqli_query($con,"INSERT INTO sellers(id,contactId,dealId,share,spouseConsentSignature,displayOrder,sendBiddingInformationBySMS,sendBiddingInformationByEmail,shouldNotSign,isDeceasedInheritor,updatedDate)VALUES('$row[id]','$row[contactId]','$row[dealId]','$row[share]','$row[spouseConsentSignature]','$row[displayOrder]','$row[sendBiddingInformationBySMS]','$row[sendBiddingInformationByEmail]','$row[shouldNotSign]','$row[isDeceasedInheritor]','$row[updatedDate]')");
}  
}

else if($_REQUEST['type'] == 'brokerJournalEntries')
{
$username = "apiaskengren@kustit.se";
$password = "apipasswordaskengren2017";
$postUrl = "https://api.mspecs.se/brokerJournalEntries?fields=id,dealId,createdDate,eventDate,userAccountId,description,isHidden,isDone,brokerJournalEventTypeId,updatedDate";
// Create a stream
$opts = array(
  'http'=>array(
    'method'=>"GET",
    'header' => "Authorization: Basic " . base64_encode("$username:$password")                 
  )
);
$context = stream_context_create($opts);
// Open the file using the HTTP headers set above
$file = file_get_contents($postUrl, false, $context);
$array = json_decode($file,true); 
mysqli_query($con,"TRUNCATE TABLE brokerJournalEntries");
    
foreach($array as $row)
{   	
  $sql = mysqli_query($con,"INSERT INTO brokerJournalEntries(id,dealId,createdDate,eventDate,userAccountId,description,isHidden,isDone,brokerJournalEventTypeId,updatedDate)VALUES('$row[id]','$row[dealId]','$row[createdDate]','$row[eventDate]','$row[userAccountId]','$row[description]','$row[isHidden]','$row[isDone]','$row[brokerJournalEventTypeId]','$row[updatedDate]')");
}  
}

else if($_REQUEST['type'] == 'documents')
{
	
$username = "apiaskengren@kustit.se";
$password = "apipasswordaskengren2017";
$postUrl = "https://api.mspecs.se/documents?fields=id,organizationUnitId,title,identifier,currentVersionId,isHidden,preValidationUrl,postValidationUrl,clonedAssociationDocumentId,clonedAssociationVersionId,createdByUserId,updatedDate";

// Create a stream
$opts = array(
  'http'=>array(
    'method'=>"GET",
    'header' => "Authorization: Basic " . base64_encode("$username:$password")                 
  )
);
$context = stream_context_create($opts);
// Open the file using the HTTP headers set above
$file = file_get_contents($postUrl, false, $context);
$array = json_decode($file,true); 
echo "<pre>";
print_r($array);
die();
mysqli_query($con,"TRUNCATE TABLE documents");
    
foreach($array as $row)
{   	
  $sql = mysqli_query($con,"INSERT INTO documents(id,organizationUnitId,title,identifier,currentVersionId,isHidden,preValidationUrl,postValidationUrl,clonedAssociationDocumentId,clonedAssociationVersionId,createdByUserId,updatedDate)VALUES('$row[id]','$row[organizationUnitId]','$row[title]','$row[identifier]','$row[currentVersionId]','$row[isHidden]','$row[preValidationUrl]','$row[postValidationUrl]','$row[clonedAssociationDocumentId]','$row[clonedAssociationVersionId]','$row[createdByUserId]','$row[updatedDate]')");
}  
}

else if($_REQUEST['type'] == 'services')
{
	
$username = "apiaskengren@kustit.se";
$password = "apipasswordaskengren2017";
$postUrl = "https://api.mspecs.se/services?fields=id,providerId,header,body,identifier,descriptionURI,orderURI,editOrderURI,isHidden,isPrivate,cost,costCurrencyId,costDescription,isSystemService,presentation,emailSubject,emailTo,emailCc,emailBody,updatedDate";

// Create a stream
$opts = array(
  'http'=>array(
    'method'=>"GET",
    'header' => "Authorization: Basic " . base64_encode("$username:$password")                 
  )
);
$context = stream_context_create($opts);
// Open the file using the HTTP headers set above
$file = file_get_contents($postUrl, false, $context);
$array = json_decode($file,true); 
echo "<pre>";
print_r($array);
die();
mysqli_query($con,"TRUNCATE TABLE services");
    
foreach($array as $row)
{   	
  $sql = mysqli_query($con,"INSERT INTO services(id,providerId,header,body,identifier,descriptionURI,orderURI,editOrderURI,isHidden,isPrivate,cost,costCurrencyId,costDescription,isSystemService,presentation,emailSubject,emailTo,emailCc,emailBody,updatedDate)VALUES('$row[id]','$row[providerId]','$row[header]','$row[body]','$row[identifier]','$row[descriptionURI]','$row[orderURI]','$row[editOrderURI]','$row[isHidden]','$row[isPrivate]','$row[cost]','$row[costCurrencyId]','$row[costDescription]','$row[isSystemService]','$row[presentation]','$row[emailSubject]','$row[emailTo]','$row[emailCc]','$row[emailBody]','$row[updatedDate]')");
}  
}

else if($_REQUEST['type'] == 'servicesInDeals')
{
	
$username = "apiaskengren@kustit.se";
$password = "apipasswordaskengren2017";
$postUrl = "https://api.mspecs.se/servicesInDeals?fields=id,dealId,serviceId,contactId,cost,externalId,description,isDelivered,isDeliveryAccepted,hasChanged,createdDate,commissionHasBeenCharged,updatedDate";

// Create a stream
$opts = array(
  'http'=>array(
    'method'=>"GET",
    'header' => "Authorization: Basic " . base64_encode("$username:$password")                 
  )
);
$context = stream_context_create($opts);
// Open the file using the HTTP headers set above
$file = file_get_contents($postUrl, false, $context);
$array = json_decode($file,true); 
echo "<pre>";
print_r($array);
die();
mysqli_query($con,"TRUNCATE TABLE servicesInDeals");
    
foreach($array as $row)
{   	
  $sql = mysqli_query($con,"INSERT INTO servicesInDeals(id,dealId,serviceId,contactId,cost,externalId,description,isDelivered,isDeliveryAccepted,hasChanged,createdDate,commissionHasBeenCharged,updatedDate)VALUES('$row[id]','$row[dealId]','$row[serviceId]','$row[contactId]','$row[cost]','$row[externalId]','$row[description]','$row[isDelivered]','$row[isDeliveryAccepted]','$row[hasChanged]','$row[createdDate]','$row[commissionHasBeenCharged]','$row[updatedDate]')");
}  
}

else if($_REQUEST['type'] == 'commissionCuts')
{
	
$username = "apiaskengren@kustit.se";
$password = "apipasswordaskengren2017";
$postUrl = "https://api.mspecs.se/commissionCuts?fields=id,commissionId,contactId,bankAccountId,percentageAmount,updatedDate";

// Create a stream
$opts = array(
  'http'=>array(
    'method'=>"GET",
    'header' => "Authorization: Basic " . base64_encode("$username:$password")                 
  )
);
$context = stream_context_create($opts);
// Open the file using the HTTP headers set above
$file = file_get_contents($postUrl, false, $context);
$array = json_decode($file,true); 
echo "<pre>";
print_r($array);
die();
mysqli_query($con,"TRUNCATE TABLE commissionCuts");
    
foreach($array as $row)
{   	
  $sql = mysqli_query($con,"INSERT INTO commissionCuts(id,commissionId,contactId,bankAccountId,percentageAmount,updatedDate)VALUES('$row[id]','$row[commissionId]','$row[contactId]','$row[bankAccountId]','$row[percentageAmount]','$row[updatedDate]')");
}  
}

else if($_REQUEST['type'] == 'commissionIntervals')
{
	
$username = "apiaskengren@kustit.se";
$password = "apipasswordaskengren2017";
$postUrl = "https://api.mspecs.se/commissionIntervals?fields=id,commissionId,percentage,lowerBound,upperBound,updatedDate";

// Create a stream
$opts = array(
  'http'=>array(
    'method'=>"GET",
    'header' => "Authorization: Basic " . base64_encode("$username:$password")                 
  )
);
$context = stream_context_create($opts);
// Open the file using the HTTP headers set above
$file = file_get_contents($postUrl, false, $context);
$array = json_decode($file,true); 
echo "<pre>";
print_r($array);
die();
mysqli_query($con,"TRUNCATE TABLE commissionIntervals");
    
foreach($array as $row)
{   	
  $sql = mysqli_query($con,"INSERT INTO commissionIntervals(id,commissionId,percentage,lowerBound,upperBound,updatedDate)VALUES('$row[id]','$row[commissionId]','$row[percentage]','$row[lowerBound]','$row[upperBound]','$row[updatedDate]')");
}  
}

else if($_REQUEST['type'] == 'commissions')
{
	
$username = "apiaskengren@kustit.se";
$password = "apipasswordaskengren2017";
$postUrl = "https://api.mspecs.se/commissions?fields=id,minimumCommissionFee,maximumCommissionFee,paymentDate,discountPercentage,discountAmount,isDiscountInPercentage,isIncludeInSettlement,commissionSum,commissionBaseFee,commissionType,showBrokerAccountInSettlement,showDealTokenInSettlement,commissionReportedDate,companyCutPercentage,showCutInReports,isSoldWithoutVAT,updatedDate";

// Create a stream
$opts = array(
  'http'=>array(
    'method'=>"GET",
    'header' => "Authorization: Basic " . base64_encode("$username:$password")                 
  )
);
$context = stream_context_create($opts);
// Open the file using the HTTP headers set above
$file = file_get_contents($postUrl, false, $context);
$array = json_decode($file,true); 
echo "<pre>";
print_r($array);
die();
mysqli_query($con,"TRUNCATE TABLE commissions");
    
foreach($array as $row)
{   	
  $sql = mysqli_query($con,"INSERT INTO commissions(id,minimumCommissionFee,maximumCommissionFee,paymentDate,discountPercentage,discountAmount,isDiscountInPercentage,isIncludeInSettlement,commissionSum,commissionBaseFee,commissionType,showBrokerAccountInSettlement,showDealTokenInSettlement,commissionReportedDate,companyCutPercentage,showCutInReports,isSoldWithoutVAT,updatedDate)VALUES('$row[id]','$row[minimumCommissionFee]','$row[maximumCommissionFee]','$row[paymentDate]','$row[discountPercentage]','$row[discountAmount]','$row[isDiscountInPercentage]','$row[isIncludeInSettlement]','$row[commissionSum]','$row[commissionBaseFee]','$row[commissionType]','$row[showBrokerAccountInSettlement]','$row[showDealTokenInSettlement]','$row[commissionReportedDate]','$row[companyCutPercentage]','$row[showCutInReports]','$row[isSoldWithoutVAT]','$row[updatedDate]')");
}  
}

else if($_REQUEST['type'] == 'capitalGainCalculationImprovements')
{
	
$username = "apiaskengren@kustit.se";
$password = "apipasswordaskengren2017";
$postUrl = "https://api.mspecs.se/capitalGainCalculationImprovements?fields=id,capitalGainCalculationId,year,description,cost,costDeduction,repairAndMaintenance,newAndRemodelling,updatedDate";

// Create a stream
$opts = array(
  'http'=>array(
    'method'=>"GET",
    'header' => "Authorization: Basic " . base64_encode("$username:$password")                 
  )
);
$context = stream_context_create($opts);
// Open the file using the HTTP headers set above
$file = file_get_contents($postUrl, false, $context);
$array = json_decode($file,true); 
echo "<pre>";
print_r($array);
die();
mysqli_query($con,"TRUNCATE TABLE capitalGainCalculationImprovements");
    
foreach($array as $row)
{   	
  $sql = mysqli_query($con,"INSERT INTO capitalGainCalculationImprovements(id,capitalGainCalculationId,year,description,cost,costDeduction,repairAndMaintenance,newAndRemodelling,updatedDate)VALUES('$row[id]','$row[capitalGainCalculationId]','$row[year]','$row[description]','$row[cost]','$row[costDeduction]','$row[repairAndMaintenance]','$row[newAndRemodelling]','$row[updatedDate]')");
}  
}

else if($_REQUEST['type'] == 'capitalGainCalculationSellers')
{
	
$username = "apiaskengren@kustit.se";
$password = "apipasswordaskengren2017";
$postUrl = "https://api.mspecs.se/capitalGainCalculationSellers?fields=id,capitalGainCalculationId,sellerId,reversalOfDeferralAmount,oldShare,isForcedSale,deferral,newProperty,propertyName,newShare,dateOfSettlement,identifier,apartmentNumber,contractDate,price,newAndRemodeling,propertyUsedAsPermanentOrHolidayLivingFullPeriod,livingPeriodFromDate,livingPeriodToDate,propertyUsedForPermanentOrHolidayLiving,livedOnPropertyFromDate,livedOnPropertyToDate,beenLivingOneYearPrecedingSale,beenLiving3OfLast5YearsBeforeSale,acquiredNewHomeBeforeSale,reversalOfImpairment,departsFromProfit,deprecationForCompensationFundForLand,updatedDate";

// Create a stream
$opts = array(
  'http'=>array(
    'method'=>"GET",
    'header' => "Authorization: Basic " . base64_encode("$username:$password")                 
  )
);
$context = stream_context_create($opts);
// Open the file using the HTTP headers set above
$file = file_get_contents($postUrl, false, $context);
$array = json_decode($file,true); 
echo "<pre>";
print_r($array);
die();
mysqli_query($con,"TRUNCATE TABLE capitalGainCalculationSellers");
    
foreach($array as $row)
{   	
  $sql = mysqli_query($con,"INSERT INTO capitalGainCalculationSellers(id,capitalGainCalculationId,sellerId,reversalOfDeferralAmount,oldShare,isForcedSale,deferral,newProperty,propertyName,newShare,dateOfSettlement,identifier,apartmentNumber,contractDate,price,newAndRemodeling,propertyUsedAsPermanentOrHolidayLivingFullPeriod,livingPeriodFromDate,livingPeriodToDate,propertyUsedForPermanentOrHolidayLiving,livedOnPropertyFromDate,livedOnPropertyToDate,beenLivingOneYearPrecedingSale,beenLiving3OfLast5YearsBeforeSale,acquiredNewHomeBeforeSale,reversalOfImpairment,departsFromProfit,deprecationForCompensationFundForLand,updatedDate)VALUES('$row[id]','$row[capitalGainCalculationId]','$row[sellerId]','$row[reversalOfDeferralAmount]','$row[oldShare]','$row[isForcedSale]','$row[deferral]','$row[newProperty]','$row[propertyName]','$row[newShare]','$row[dateOfSettlement]','$row[identifier]','$row[apartmentNumber]','$row[contractDate]','$row[price]','$row[newAndRemodeling]','$row[propertyUsedAsPermanentOrHolidayLivingFullPeriod]','$row[livingPeriodFromDate]','$row[livingPeriodToDate]','$row[propertyUsedForPermanentOrHolidayLiving]$row','$row[livedOnPropertyFromDate]$row','$row[livedOnPropertyToDate]','$row[beenLivingOneYearPrecedingSale]','$row[beenLiving3OfLast5YearsBeforeSale]','$row[acquiredNewHomeBeforeSale]','$row[reversalOfImpairment]','$row[departsFromProfit]','$row[deprecationForCompensationFundForLand]',$row'[updatedDate]')");
}  
}

else if($_REQUEST['type'] == 'capitalGainCalculations')
{
	
$username = "apiaskengren@kustit.se";
$password = "apipasswordaskengren2017";
$postUrl = "https://api.mspecs.se/capitalGainCalculations?fields=id,kType,saleContractDate,salePrice,saleCommission,saleValuation,saleInspection,saleOtherCosts,saleRepairFundAmount,saleApartmentEquipment,buyContractDate,buyPrice,buyAssetValue1952,buyLandRegistrationFee,buyMortgageFee,buyInspection,buyOtherCosts,buyPriceSum,buyCostsSum,buyApartmentEquipment,buySpecialCharges,buyCapitalContributions,buyRepairFundAmount,saleCosts,buyCosts,result,updatedDate";

// Create a stream
$opts = array(
  'http'=>array(
    'method'=>"GET",
    'header' => "Authorization: Basic " . base64_encode("$username:$password")                 
  )
);
$context = stream_context_create($opts);
// Open the file using the HTTP headers set above
$file = file_get_contents($postUrl, false, $context);
$array = json_decode($file,true); 
echo "<pre>";
print_r($array);
die();
mysqli_query($con,"TRUNCATE TABLE capitalGainCalculations");
    
foreach($array as $row)
{   	
  $sql = mysqli_query($con,"INSERT INTO capitalGainCalculations(id,kType,saleContractDate,salePrice,saleCommission,saleValuation,saleInspection,saleOtherCosts,saleRepairFundAmount,saleApartmentEquipment,buyContractDate,buyPrice,buyAssetValue1952,buyLandRegistrationFee,buyMortgageFee,buyInspection,buyOtherCosts,buyPriceSum,buyCostsSum,buyApartmentEquipment,buySpecialCharges,buyCapitalContributions,buyRepairFundAmount,saleCosts,buyCosts,result,updatedDate)VALUES('$row[id]','$row[kType]','$row[saleContractDate]','$row[salePrice]','$row[saleCommission]','$row[saleValuation]','$row[saleInspection]','$row[saleOtherCosts]','$row[saleRepairFundAmount]','$row[saleApartmentEquipment]','$row[buyContractDate]','$row[buyPrice]','$row[buyAssetValue1952]','$row[buyLandRegistrationFee]','$row[buyMortgageFee]','$row[buyInspection]','$row[buyOtherCosts]','$row[buyPriceSum]','$row[buyCostsSum]','$row[buyApartmentEquipment]','$row[buySpecialCharges]','$row[buyCapitalContributions]','$row[buyRepairFundAmount]','$row[saleCosts]','$row[buyCosts]','$row[result]','$row[updatedDate]')");
}  
}

else if($_REQUEST['type'] == 'imagesInEstates')
{
	
$username = "apiaskengren@kustit.se";
$password = "apipasswordaskengren2017";
$postUrl = "https://api.mspecs.se/imagesInEstates?fields=id,fileId,estateId,category,updatedDate";

// Create a stream
$opts = array(
  'http'=>array(
    'method'=>"GET",
    'header' => "Authorization: Basic " . base64_encode("$username:$password")                 
  )
);
$context = stream_context_create($opts);
// Open the file using the HTTP headers set above
$file = file_get_contents($postUrl, false, $context);
$array = json_decode($file,true); 

//print_r($array);

mysqli_query($con,"TRUNCATE TABLE imagesInEstates");
    
foreach($array as $row)
{   

  mysqli_query($con,"INSERT INTO imagesInEstates(id,fileId,estateId,category,updatedDate)VALUES('$row[id]','$row[fileId]','$row[estateId]','$row[category]','$row[updatedDate]')");
}  
}

else if($_REQUEST['type'] == 'imagesInRooms')
{
	
$username = "apiaskengren@kustit.se";
$password = "apipasswordaskengren2017";
$postUrl = "https://api.mspecs.se/imagesInRooms?fields=id,fileId,roomId,updatedDate";

// Create a stream
$opts = array(
  'http'=>array(
    'method'=>"GET",
    'header' => "Authorization: Basic " . base64_encode("$username:$password")                 
  )
);
$context = stream_context_create($opts);
// Open the file using the HTTP headers set above
$file = file_get_contents($postUrl, false, $context);
$array = json_decode($file,true); 

//print_r($array);

mysqli_query($con,"TRUNCATE TABLE imagesInRooms");
    
foreach($array as $row)
{   

  mysqli_query($con,"INSERT INTO imagesInRooms(id,fileId,roomId,updatedDate)VALUES('$row[id]','$row[fileId]','$row[roomId]','$row[updatedDate]')");
}  
}

else if($_REQUEST['type'] == 'rooms')
{
	
$username = "apiaskengren@kustit.se";
$password = "apipasswordaskengren2017";
$postUrl = "https://api.mspecs.se/rooms?fields=id,estateId";

// Create a stream
$opts = array(
  'http'=>array(
    'method'=>"GET",
    'header' => "Authorization: Basic " . base64_encode("$username:$password")                 
  )
);
$context = stream_context_create($opts);
// Open the file using the HTTP headers set above
$file = file_get_contents($postUrl, false, $context);
$array = json_decode($file,true); 

//print_r($array);

mysqli_query($con,"TRUNCATE TABLE rooms");
    
foreach($array as $row)
{   

  mysqli_query($con,"INSERT INTO rooms(id,estateId)VALUES('$row[id]','$row[estateId]')");
}  
}


else if($_REQUEST['type'] == 'imagesInDeals')
{
	
$username = "apiaskengren@kustit.se";
$password = "apipasswordaskengren2017";
$postUrl = "https://api.mspecs.se/imagesInDeals?fields=id,fileId,dealId,category,updatedDate";

// Create a stream
$opts = array(
  'http'=>array(
    'method'=>"GET",
    'header' => "Authorization: Basic " . base64_encode("$username:$password")                 
  )
);
$context = stream_context_create($opts);
// Open the file using the HTTP headers set above
$file = file_get_contents($postUrl, false, $context);
$array = json_decode($file,true); 

//print_r($array);

mysqli_query($con,"TRUNCATE TABLE imagesInDeals");
    
foreach($array as $row)
{   

  mysqli_query($con,"INSERT INTO imagesInDeals(id,fileId,dealId,category,updatedDate)VALUES('$row[id]','$row[fileId]','$row[dealId]','$row[category]','$row[updatedDate]')");
}  
}


else if($_REQUEST['type'] == 'buildings')
{
	
$username = "apiaskengren@kustit.se";
$password = "apipasswordaskengren2017";
$postUrl = "https://api.mspecs.se/buildings?fields=id,estateId,buildingType,numberOfRooms,numberOfBedrooms,livingArea,otherLivingArea,roomsDescription,buildYear,ventilationType,windowsType,chimneyType,chimneyComment,drainType,waterType,heatingType,energyConsumption,energyClass,energyStatus,area";

// Create a stream
$opts = array(
  'http'=>array(
    'method'=>"GET",
    'header' => "Authorization: Basic " . base64_encode("$username:$password")                 
  )
);
$context = stream_context_create($opts);
// Open the file using the HTTP headers set above
$file = file_get_contents($postUrl, false, $context);
$array = json_decode($file,true); 

//print_r($array);

mysqli_query($con,"TRUNCATE TABLE buildings");
    
foreach($array as $row)
{   

  mysqli_query($con,"INSERT INTO buildings(id,estateId,buildingType,numberOfRooms,numberOfBedrooms,livingArea,otherLivingArea,roomsDescription,buildYear,ventilationType,windowsType,chimneyType,chimneyComment,drainType,waterType,heatingType,energyConsumption,energyClass,energyStatus,area)VALUES('$row[id]','$row[estateId]','$row[buildingType]','$row[numberOfRooms]','$row[numberOfBedrooms]','$row[livingArea]','$row[otherLivingArea]','$row[roomsDescription]','$row[buildYear]','$row[ventilationType]','$row[windowsType]','$row[chimneyType]','$row[chimneyComment]','$row[drainType]','$row[waterType]','$row[heatingType]','$row[energyConsumption]','$row[energyClass]','$row[energyStatus]','$row[area]')");
}  
}

else if($_REQUEST['type'] == 'buildings')
{
	
$username = "apiaskengren@kustit.se";
$password = "apipasswordaskengren2017";
$postUrl = "https://api.mspecs.se/buildings?fields=id,estateId,buildingType,numberOfRooms,numberOfBedrooms,livingArea,otherLivingArea,roomsDescription,buildYear,ventilationType,windowsType,chimneyType,chimneyComment,drainType,waterType,heatingType,energyConsumption,energyClass,energyStatus,area";

// Create a stream
$opts = array(
  'http'=>array(
    'method'=>"GET",
    'header' => "Authorization: Basic " . base64_encode("$username:$password")                 
  )
);
$context = stream_context_create($opts);
// Open the file using the HTTP headers set above
$file = file_get_contents($postUrl, false, $context);
$array = json_decode($file,true); 

//print_r($array);

mysqli_query($con,"TRUNCATE TABLE buildings");
    
foreach($array as $row)
{   

  mysqli_query($con,"INSERT INTO buildings(id,estateId,buildingType,numberOfRooms,numberOfBedrooms,livingArea,otherLivingArea,roomsDescription,buildYear,ventilationType,windowsType,chimneyType,chimneyComment,drainType,waterType,heatingType,energyConsumption,energyClass,energyStatus,area)VALUES('$row[id]','$row[estateId]','$row[buildingType]','$row[numberOfRooms]','$row[numberOfBedrooms]','$row[livingArea]','$row[otherLivingArea]','$row[roomsDescription]','$row[buildYear]','$row[ventilationType]','$row[windowsType]','$row[chimneyType]','$row[chimneyComment]','$row[drainType]','$row[waterType]','$row[heatingType]','$row[energyConsumption]','$row[energyClass]','$row[energyStatus]','$row[area]')");
}  
}

else if($_REQUEST['type'] == 'mortgages')
{
	
$username = "apiaskengren@kustit.se";
$password = "apipasswordaskengren2017";
$postUrl = "https://api.mspecs.se/mortgages?fields=id,estateId,amount,logEntryId,displayOrder";

// Create a stream
$opts = array(
  'http'=>array(
    'method'=>"GET",
    'header' => "Authorization: Basic " . base64_encode("$username:$password")                 
  )
);
$context = stream_context_create($opts);
// Open the file using the HTTP headers set above
$file = file_get_contents($postUrl, false, $context);
$array = json_decode($file,true); 

//print_r($array);

mysqli_query($con,"TRUNCATE TABLE mortgages");
    
foreach($array as $row)
{   

  mysqli_query($con,"INSERT INTO mortgages(id,estateId,amount,logEntryId,displayOrder)VALUES('$row[id]','$row[estateId]','$row[amount]','$row[logEntryId]','$row[displayOrder]')");
}  
}

 ?>
