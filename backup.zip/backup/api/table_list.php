<?php
// curl check 
/*if( ini_get('allow_url_fopen') ) {
    echo "its enabled, so do something";
}
else {
    echo " its not enabled, so do something else";
}*/

$username = "apiaskengren@kustit.se";
$password = "apipasswordaskengren2017";
  //https://api.mspecs.se/deals?fields=id,displayName,objectStatus&sort=displayName
$postUrl = "https://api.mspecs.se/schema/deals";
        
//$toSend = "?fields=id,displayName";


// Create a stream
$opts = array(
  'http'=>array(
    'method'=>"GET",
    'header' => "Authorization: Basic " . base64_encode("$username:$password")                 
  )
);

$context = stream_context_create($opts);

// Open the file using the HTTP headers set above
$file = file_get_contents($postUrl, false, $context);
echo "<pre>"; 
print($file);


exit;


        function curlCall($postUrl, $toSend)
        {
          $ch = curl_init();
          curl_setopt($ch, CURLOPT_POST, 0);
          //curl_setopt( $ch, CURLOPT_CUSTOMREQUEST, 'GET' );
          curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);//CURLAUTH_BASIC OR CURLAUTH_ANY
          curl_setopt($curl, CURLOPT_USERPWD, "$username : $password"); //Your credentials goes here
          curl_setopt($ch, CURLOPT_URL, $postUrl);
          curl_setopt($ch, CURLOPT_POSTFIELDS, $toSend);
          curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
          curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
          curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
          curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
          $out = curl_exec($ch);
          return $out;
        }
        $json = curlCall($postUrl, $toSend, $username, $password);
        $decode = json_decode($json);

print_r($json);
die;
        $access_token = $decode->result->body->access_token;
        $token_type = $decode->result->body->token_type;
        $refresh_token = $decode->result->body->refresh_token;

        $response['access_token'] = $access_token;
?>