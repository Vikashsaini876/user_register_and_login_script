<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * @since 2.0
 */
class AC_Column_User_Actions extends AC_Column_Actions {

	protected function get_object_type() {
		return 'user';
	}

}
