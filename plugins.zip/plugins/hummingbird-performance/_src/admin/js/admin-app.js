jQuery(document).ready( function() {
    WPHB_Admin.init();
});