<?php

    // Nothing here! Nobody should access this file legitimately... Come on get out! 

?>

You are a very naughty boy (or girl)!