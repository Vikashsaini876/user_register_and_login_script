<?php
/**
 * @package Techotronic
 * @subpackage All in one Favicon
 *
 * @since 4.0
 * @author Arne Franken
 *
 * Footer for settings page
 */
?>
<div class="clear">
  <p>
    <br/>&copy; Copyright 2010 - <?php echo date("Y"); ?> <a href="http://www.techotronic.de" target="_blank">Arne Franken</a>
  </p>
</div>